<article id="entry-<?php the_ID(); ?>" <?php post_class( 'entry-item entry-item-vertical entry-item-reveal' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<figure class="entry-item-thumb">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'brittany_vertical' ); ?>
			</a>
		</figure>
	<?php endif; ?>

	<div class="entry-item-content-wrap">
		<div class="entry-item-content">
			<?php if ( get_post_type() === 'post' ) : ?>
				<p class="entry-meta">
					<?php brittany_the_post_entry_sticky_label(); ?>

					<time class="entry-time" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
				</p>
			<?php endif; ?>

			<h2 class="entry-item-title">
				<a href="<?php the_permalink(); ?>">
					<?php the_title(); ?>
				</a>
			</h2>
		</div>

		<div class="entry-item-footer">
			<?php if ( get_post_type() === 'post' ) : ?>
				<div class="entry-item-categories">
					<?php the_category( ', ' ); ?>
				</div>
			<?php endif; ?>

			<?php get_template_part( 'part-social-sharing' ); ?>
		</div>
	</div>
</article>
