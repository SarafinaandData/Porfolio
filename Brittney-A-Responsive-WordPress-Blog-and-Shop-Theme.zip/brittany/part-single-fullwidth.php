<main class="main">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<?php while ( have_posts() ) : the_post(); ?>
					<article id="entry-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
						<?php if ( has_post_thumbnail() && 1 !== (int) get_post_meta( get_the_ID(), 'brittany_hide_featured', true ) ) : ?>
							<div class="entry-thumb">
								<a class="ci-lightbox" href="<?php echo esc_url( wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' ) ); ?>">
									<?php the_post_thumbnail( 'brittany_fullwidth' ); ?>
								</a>
							</div>
						<?php endif; ?>

						<?php if ( get_theme_mod( 'single_date', 1 ) || get_theme_mod( 'single_categories', 1 ) || get_theme_mod( 'single_comments', 1 ) ) : ?>
							<div class="entry-meta">
								<?php if ( get_theme_mod( 'single_date', 1 ) ) : ?>
									<time class="entry-time" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
								<?php endif; ?>

								<?php if ( get_theme_mod( 'single_categories', 1 ) ) : ?>
									<div class="entry-categories">
										<?php the_category( ', ' ); ?>
									</div>
								<?php endif; ?>

								<?php if ( get_theme_mod( 'single_comments', 1 ) ) : ?>
									<a href="<?php echo esc_url( get_comments_link() ); ?>" class="entry-comments-no"><?php comments_number(); ?></a>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<h1 class="entry-title">
							<?php the_title(); ?>
						</h1>

						<div class="entry-content">
							<?php the_content(); ?>
							<?php wp_link_pages(); ?>
						</div>

						<?php if ( get_theme_mod( 'single_signature', 1 ) ) {
							get_template_part( 'part-signature' );
						} ?>

						<?php if ( ( get_theme_mod( 'single_tags', 1 ) && has_tag() ) || get_theme_mod( 'single_social_sharing', 1 ) ) : ?>
							<div class="row-table">
								<?php if ( get_theme_mod( 'single_tags', 1 ) ) : ?>
									<div class="row-table-left">
										<?php the_tags( '<div class="entry-tags">', ', ', '</div>' ); ?>
									</div>
								<?php endif; ?>

								<?php if ( get_theme_mod( 'single_social_sharing', 1 ) ) : ?>
									<div class="row-table-right">
										<?php get_template_part( 'part-social-sharing' ); ?>
									</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<?php if ( get_theme_mod( 'single_authorbox', 1 ) ) {
							get_template_part( 'part-authorbox' );
						} ?>

						<?php if ( get_theme_mod( 'single_related', 1 ) ) {
							get_template_part( 'part-related' );
						} ?>

						<?php if ( get_theme_mod( 'single_comments', 1 ) ) {
							comments_template();
						} ?>
					</article>
				<?php endwhile; ?>
			</div>

			<?php get_template_part( 'part-prefooter' ); ?>
		</div>
	</div>
</main>
