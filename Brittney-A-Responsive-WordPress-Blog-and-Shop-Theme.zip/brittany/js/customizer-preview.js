/**
 * Base Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Base Theme Customizer preview reload changes asynchronously.
 *
 * https://developer.wordpress.org/themes/customize-api/tools-for-improved-user-experience/#using-postmessage-for-improved-setting-previewing
 */

(function ($) {
	function createStyleSheet(settingName, styles) {
		var $styleElement;

		style = '<style class="' + settingName + '">';
		style += styles.reduce(function (rules, style) {
			rules += style.selectors + '{' + style.property + ':' + style.value + ';} ';
			return rules;
		}, '');
		style += '</style>';

		$styleElement = $('.' + settingName);

		if ($styleElement.length) {
			$styleElement.replaceWith(style);
		} else {
			$('head').append(style);
		}
	}

	//
	// Theme global colors
	//
	wp.customize('global_secondary_bg_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_secondary_bg_color', [
				{
					property: 'background-color',
					value: to,
					selectors: 'input,textarea,.images > a img,.footer,.header-bar,.header-bar-wrap,.searchform-header,.cart-dropdown-content-wrap,.entry-item-content-wrap,.entry-item-media:hover .entry-item-media-content,.entry-thumb,.entry-content img,#paging a:hover,#paging .current,.searchform,.newsletter-form,.widget-about .widget-about-avatar img,.social-icon:hover,.wp-caption,.navigation a',
				},
				{
					property: 'border-color',
					value: to,
					selectors: '.entry-item::after,.entry-item-fixed,section.widget .instagram-pics li a::after',
				}
			]);
		});
	});

	wp.customize('global_primary_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_primary_color', [
				{
					property: 'color',
					value: to,
					selectors: 'a, a:hover,.item-title a:hover,.btn:hover,input[type="button"]:hover,input[type="submit"]:hover,input[type="reset"]:hover,button:hover,.comment-author a:hover,.comment-metadata a:hover,.main-search-trigger:hover,.entry-item-title:hover a,.entry-item-categories a:hover,.entry-item-sharing a:hover,.entry-slide-control a:hover,.entry-title:hover a,.entry-meta a:hover,.entry-content blockquote::before,.row-table-left a:not(.btn):hover,.row-table-right a:not(.btn):hover,#paging a:hover,#paging .current,.navigation > li > a:hover,.navigation > li.sfHover > a,.navigation > li.sfHover > a:active,.navigation > li.current_page_item > a,.navigation > li.current-menu-item > a,.navigation > li.current-menu-ancestor > a,.navigation > li.current-menu-parent > a,.navigation > li.current > a,.navigation > li ul a:hover,.navigation > li ul .sfHover > a,.social-icon:hover',
				},
				{
					property: 'background-color',
					value: to,
					selectors: '.btn,input[type="button"],input[type="submit"],input[type="reset"],button,.woocommerce-message,.woocommerce-error,.woocommerce-info,.woocommerce-noreviews,.onsale,.woocommerce-product-gallery__trigger,.product .summary ul li:before,.shop_attributes th:first-child:before,.cart-dropdown:hover .cart-dropdown-toggle,.cart-dropdown.cart-dropdown-open .cart-dropdown-toggle,.ci-badge,.price_slider .ui-slider-handle, .qty-btn:hover'
				},
				{
					property: 'border-color',
					value: to,
					selectors: '.cart-dropdown.cart-dropdown-open .cart-dropdown-toggle .ci-badge,.cart-dropdown:hover .cart-dropdown-toggle .ci-badge',
				}
			]);
		});
	});

	wp.customize('global_text_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_text_color', [
				{
					property: 'color',
					value: to,
					selectors: 'body,.comment-author a,.comment-metadata a,.form-allowed-tags,.comment-notes,.woocommerce-tabs .tabs li a,.shop_table .product-remove .remove,.widget .instagram-pics li a,.site-logo a,.mobile-nav-trigger:hover,.mobile-nav-trigger:active,.section-title label,.entry-item-title a,.entry-title a,#paging a,#paging > span,#paging li span,.navigation a,.widget-title label,.woocommerce-MyAccount-navigation-link.is-active a, .main-search-trigger,.cart-dropdown:hover .cart-dropdown-toggle .ci-badge,.cart-dropdown.cart-dropdown-open .cart-dropdown-toggle .ci-,.cart-dropdown-toggle,.mobile-nav-trigger,.entry-item-sharing a,.entry-slide-control a,.entry-meta a,.row-table-right a,.social-icon,.wp-caption .wp-caption-text,blockquote cite,label,.comment-author,.comment-metadata,.product_meta,.product .summary .stock,.shop_table th,.cart_totals table th,.cart_totals table td,.price_slider_wrapper,.price_slider_amount,.site-tagline,.section-title small,.entry-item-categories a,.entry-meta,.row-table-left a:not(.btn)',
				},
				{
					property: 'background-color',
					value: to,
					selectors: '.qty-btn',
				}
			]);
		});
	});

	wp.customize('global_link_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_link_color', [
				{
					property: 'color',
					value: to,
					selectors: '.entry-content a,.entry-content a:hover',
				}
			]);
		});
	});

	wp.customize('global_link_hover_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_link_hover_color', [
				{
					property: 'color',
					value: to,
					selectors: '.entry-content a:hover',
				}
			]);
		});
	});

	wp.customize('global_btn_text_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_btn_text_color', [
				{
					property: 'color',
					value: to,
					selectors: '.btn,input[type="button"],input[type="submit"],input[type="reset"],button,.comment-reply-link, .sidebar .btn, .sidebar .button',
				}
			]);
		});
	});

	wp.customize('global_btn_bg_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_btn_bg_color', [
				{
					property: 'background-color',
					value: to,
					selectors: '.btn,input[type="button"],input[type="submit"],input[type="reset"],button,.comment-reply-link',
				}
			]);
		});
	});

	wp.customize('global_btn_hover_bg_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_btn_hover_bg_color', [
				{
					property: 'background-color',
					value: to,
					selectors: '.btn:hover,input[type="button"]:hover,input[type="submit"]:hover,input[type="reset"]:hover,button:hover,.comment-reply-link:hover',
				}
			]);
		});
	});

	wp.customize('global_border_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('global_border_color', [
				{
					property: 'border-color',
					value: to,
					selectors: '.widget select,input,textarea,.payment_box,.myaccount_user,.woocommerce fieldset,.searchform-,.cart-dropdown-content-wrap,.entry-item-fixed:hover .entry-item-content-wrap,.row-table,#paging a,#paging > span,#paging li span,.widget select,.social-icon',
				},
				{
					property: 'border-top-color',
					value: to,
					selectors: '#comments h2,#comments h3,.woocommerce-tabs,.shop_attributes tr:first-child th,.shop_attributes tr:first-child td,#order_review_heading,.widget_shopping_cart_content .total,.footer,.section-title,.entry-item-footer,.navigation ul ul,.widget-title',
				},
				{
					property: 'border-bottom-color',
					value: to,
					selectors: '.shop-actions,.product .summary ul li,.product .summary ul li:first-child,.woocommerce-tabs,.woocommerce-tabs .tabs li,.woocommerce-tabs .pane-container,.woocommerce-tabs .panel #tab-reviews #reply-title,.shop_attributes th,.shop_attributes td,.shop_table th,.shop_table td,.cart_totals h2,.cart_totals table th,.cart_totals table td,.shipping-calculator-button,.woocommerce form.login .lost_password a,.payment_methods li,.widget_shopping_cart_content .total,.header-bar,.entry-item-content-wrap,.navigation > li ul a,.widget_recent_comments ul li,.woocommerce-MyAccount-navigation-link a',
				},
				{
					property: 'border-right-color',
					value: to,
					selectors: '.header-bar-right,.main-search-trigger,.mobile-nav-trigger,.entry-item-content-wrap,.navigation > li > a,.navigation ul',
				},
				{
					property: 'border-left-color',
					value: to,
					selectors: '.header-bar-right,.main-search-trigger,.cart-dropdown-toggle,.mobile-nav-trigger,.entry-item-content-wrap,.entry-item-categories + .entry-item-sharing,.entry-item-title + .entry-item-sharing,.entry-slide-control,.entry-slide-control .entry-slide-next,.row-table-left + .row-table-right,#paging > a:not(.page-numbers):nth-child(2),.nav,.navigation ul',
				}
			]);
		});
	});

	//
	// Header
	//
	wp.customize('header_bg_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('header_bg_color', [
				{
					property: 'background-color',
					value: to,
					selectors: '.header-bar-wrap,.cart-dropdown-content-wrap,.searchform-header,.header-bar,.navigation a,.header .social-icon:hover',
				}
			]);
		});
	});

	wp.customize('header_text_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('header_text_color', [
				{
					property: 'color',
					value: to,
					selectors: '.header a,.navigation a',
				}
			]);
		});
	});

	wp.customize('header_hover_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('header_hover_color', [
				{
					property: 'color',
					value: to,
					selectors: '.header a:hover,.navigation > li > a:hover,.navigation > li.sfHover > a,.navigation > li.sfHover > a:active,.navigation > li.current_page_item > a,.navigation > li.current-menu-item > a,.navigation > li.current-menu-ancestor > a,.navigation > li.current-menu-parent > a,.navigation > li.current > a,.navigation > li ul a:hover,.navigation > li ul .sfHover > a',
				}
			]);
		});
	});

	wp.customize('header_border_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('header_border_color', [
				{
					property: 'border-color',
					value: to,
					selectors: '.searchform-header,.header .social-icon,.header input',
				},
				{
					property: 'border-top-color',
					value: to,
					selectors: '.navigation ul ul',
				},
				{
					property: 'border-bottom-color',
					value: to,
					selectors: '.navigation > li ul a,.header-bar',
				},
				{
					property: 'border-left-color',
					value: to,
					selectors: '.nav,.navigation ul,.main-search-trigger,.cart-dropdown-toggle,.mobile-nav-trigger',
				},
				{
					property: 'border-right-color',
					value: to,
					selectors: '.navigation > li a,.navigation ul,.header-bar-right,.main-search-trigger,.header-bar-right',
				}
			]);
		});
	});

	//
	// Sidebar
	//
	wp.customize('sidebar_bg_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('sidebar_bg_color', [
				{
					property: 'background-color',
					value: to,
					selectors: '.sidebar',
				},
				{
					property: 'padding',
					value: !!to ? '15px' : '0',
					selectors: '.sidebar',
				}
			]);
		});
	});

	wp.customize('sidebar_text_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('sidebar_text_color', [
				{
					property: 'color',
					value: to,
					selectors: '.sidebar',
				}
			]);
		});
	});

	wp.customize('sidebar_link_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('sidebar_link_color', [
				{
					property: 'color',
					value: to,
					selectors: '.sidebar a,.sidebar a:hover',
				}
			]);
		});
	});

	wp.customize('sidebar_hover_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('sidebar_hover_color', [
				{
					property: 'color',
					value: to,
					selectors: '.sidebar a:hover',
				}
			]);
		});
	});

	wp.customize('sidebar_title_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('sidebar_title_color', [
				{
					property: 'color',
					value: to,
					selectors: '.sidebar .widget-title',
				}
			]);
		});
	});

	wp.customize('sidebar_border_color', function (value) {
		value.bind(function (to) {
			createStyleSheet('sidebar_border_color', [
				{
					property: 'border-color',
					value: to,
					selectors: '.sidebar input,.sidebar textarea',
				},
				{
					property: 'border-top-color',
					value: to,
					selectors: '.widget-title',
				}
			]);
		});
	});

})(jQuery);
