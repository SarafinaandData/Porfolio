jQuery(function( $ ) {
	'use strict';

	var $body = $('body');

	/* -----------------------------------------
	Responsive Menus Init with mmenu
	----------------------------------------- */
	var $mainNav   = $( '.navigation' );
	var $mobileNav = $( '#mobilemenu' );

	$mainNav.clone().removeAttr( 'id' ).removeClass().appendTo( $mobileNav );
	$mobileNav.find( 'li' ).removeAttr( 'id' );

	$mobileNav.mmenu({
		offCanvas: {
			position: 'top',
			zposition: 'front'
		},
		"autoHeight": false,
		"navbars": [
			{
				"position": "top",
				"content": [
					"prev",
					"title",
					"close"
				]
			}
		]
	});

	/* -----------------------------------------
	Main Navigation Init
	----------------------------------------- */
	$mainNav.superfish({
		delay: 300,
		animation: { opacity: 'show', height: 'show' },
		speed: 'fast',
		dropShadows: false
	});

	/* -----------------------------------------
	Header search bar hide/show and head cart
	----------------------------------------- */
	var $searchTrigger = $('.main-search-trigger');
	var $headSearch = $('.header-search-wrap');
	var $cartToggle = $('.cart-dropdown-toggle');
	var $headCart = $cartToggle.parent();

	$cartToggle.on('click', function(e) {
		e.preventDefault();

		var $this = $(this);
		$this.parent().toggleClass('cart-dropdown-open');
	});

	$searchTrigger.on('click', function(e) {
		e.preventDefault();
		$headSearch.toggleClass('searchform-visible');
		if ( $headSearch.hasClass('searchform-visible') ) {
			$headSearch.find('input').focus();
		}
	});

	document.onkeydown = function(e) {
		e = e || window.e;
		if ( e.keyCode === 27 && $headSearch.hasClass('searchform-visible') ) {
			$headSearch.removeClass('searchform-visible');
		}
	};

	$body.on('click', function() {
		if ( $headSearch.hasClass('searchform-visible') ) {
			$headSearch.removeClass('searchform-visible');
		}

		if ( $headCart.hasClass('cart-dropdown-open') ) {
			$headCart.removeClass('cart-dropdown-open');
		}
	}).find('.searchform-header, .main-search-trigger, .cart-dropdown').on('click', function(e) {
		e.stopPropagation();
	});


	/* -----------------------------------------
	 Instagram Widget
	 ----------------------------------------- */
	var $instagramWidget = $('section').find('.instagram-pics');
	var $instagramWrap = $instagramWidget.parent('div');

	if ( $instagramWidget.length ) {
		var auto = $instagramWrap.data('auto'),
			speed = $instagramWrap.data('speed');

		$instagramWidget.slick({
			slidesToShow: 6,
			slidesToScroll: 1,
			arrows: false,
			autoplay: auto === 1,
			speed: speed,
			responsive: [
				{
					breakpoint: 992,
					settings: {
						slidesToShow: 4
					}
				}
			]
		});
	}

	/* -----------------------------------------
	 WooCommerce plus minus
	 ----------------------------------------- */
	var $qtyBtn = $( '.qty-btn' );

	$qtyBtn.on( 'click', function () {
		var $this        = $( this );
		var $input       = $this.parent().find( 'input[type="number"]' );
		var placeholder  = parseInt( $input.attr('placeholder') ) || 0;
		var min          = parseInt( $input.attr( 'min' ) || 0, 10 );
		var max          = parseInt( $input.attr( 'max' ) || 99999, 10 );
		var currentVal   = parseInt($input.val(), 10) ? parseInt($input.val(), 10) : placeholder;
		var isMinus      = $this.hasClass( 'qty-minus' );

		if ( isMinus ) {
			$input.val( Math.max( currentVal - 1, min ) );
		} else {
			$input.val( Math.min( currentVal + 1, max ) );
		}
	} );

	/* -----------------------------------------
	Slick Slider Homepage
	----------------------------------------- */
	var $slickSlider = $('.home-full-slider');
	if ( $slickSlider.length ) {
		var slideshow      = $slickSlider.data( 'slideshow' );
		var slideshowspeed = $slickSlider.data( 'slideshowspeed' );

		$slickSlider.slick({
			autoplay: slideshow == 1,
			autoplaySpeed: slideshowspeed,
			centerMode: true,
			centerPadding: '30px',
			slidesToShow: 1,
			variableWidth: true,
			arrows: false,
			responsive: [
				{
					breakpoint: 1200,
					settings: {
						variableWidth: false
					}
				},
				{
					breakpoint: 768,
					settings: {
						centerMode: false,
						variableWidth: false,
						centerPadding: '5px'
					}
				}
			]
		});
	}

	/* -----------------------------------------
	Responsive Videos with fitVids
	----------------------------------------- */
	$body.fitVids();

	/* -----------------------------------------
	Image Lightbox
	----------------------------------------- */
	$( ".ci-lightbox, a[data-lightbox^='gal']" ).magnificPopup({
		type: 'image',
		mainClass: 'mfp-with-zoom',
		gallery: {
			enabled: true
		},
		zoom: {
			enabled: true
		}
	} );


	/* -----------------------------------------
	 Zoom single product thumbnails
	 ----------------------------------------- */
	$( '.woocommerce-product-gallery--with-images' ).prepend( '<a href="#" class="woocommerce-product-gallery__trigger"><i class="fa fa-search-plus"></i></a>' );

	$body.on( 'click', '.woocommerce-product-gallery__trigger', function ( e ) {
		var images = $( '.woocommerce-product-gallery__image' ).map(function () {
			return {
				src: $(this).find('a').attr('href'),
			};
		} ).get();

		if ( 1 === images.length ) {
			var currentImageIndex = $( '.woocommerce-product-gallery__image' ).index();
		} else {
			var currentImageIndex = $( '.flex-active-slide' ).index();
		}

		$.magnificPopup.open({
			type: 'image',
			gallery: {
				enabled: true,
			},
			items: images,
		}, currentImageIndex || 0);

		e.preventDefault();
	} );

	$( window ).on( 'load', function() {
		/* -----------------------------------------
		Equal Heights
		----------------------------------------- */
		$('.row-items').find('div[class^="col"]').matchHeight();

		/* -----------------------------------------
		FlexSlider Init
		----------------------------------------- */
		var $mainSlider = $( '.ci-main-slider' ).not( '.home-full-slider' );

		if ( $mainSlider.length ) {
			$mainSlider.flexslider({
				slideshow     : $mainSlider.data( 'slideshow' ),
				slideshowSpeed: $mainSlider.data( 'slideshowspeed' ),
				animationSpeed: $mainSlider.data( 'animationspeed' ),
				namespace: 'ci-',
				directionNav: false,
				controlNav: false,
				prevText: '',
				nextText: '',
				start: function( slider ) {
					slider.removeClass( 'loading' );
				}
			});
		}

		/**
		 * Slide custom control interface
		 *
		 * @param $slider slider jQuery object
		 * @param {string} direction next|prev
		 */
		var slide = function($slider, direction) {
			if ( $slider.hasClass('ci-slider') ) {
				$slider.flexslider(direction);
			} else if ( $slider.hasClass('home-full-slider') ) {
				if ( direction === 'next' ) {
					$slider.slick('slickNext');
				} else {
					$slider.slick('slickPrev');
				}
			}
		};

		var $slideControl = $( '.entry-slide-control' ).find( 'a' );
		$slideControl.on( 'click', function( e ) {
			e.preventDefault();
			var $this = $(this);
			var $slider = $this.parents( '.ci-main-slider' );

			if ( $this.hasClass( 'entry-slide-prev' ) ) {
				slide( $slider, 'prev' );
			} else {
				slide( $slider, 'next' );
			}
		});
	});
});
