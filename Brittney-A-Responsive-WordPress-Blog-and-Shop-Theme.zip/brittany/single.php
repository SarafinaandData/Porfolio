<?php get_header(); ?>

<?php
	$default_layout = get_theme_mod( 'single_post_layout', 'right-sidebar' );
	$single_layout  = get_post_meta( get_queried_object_id(), 'brittany_layout', true );
	if ( empty( $single_layout ) ) {
		get_template_part( 'part-single', $default_layout );
	} else {
		get_template_part( 'part-single', $single_layout );
	}
?>

<?php get_footer();
