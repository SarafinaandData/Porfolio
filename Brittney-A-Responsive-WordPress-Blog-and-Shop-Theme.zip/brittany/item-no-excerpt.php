<article id="entry-<?php the_ID(); ?>" <?php post_class( 'entry-item entry-item-vertical' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<figure class="entry-item-thumb">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'brittany_vertical' ); ?>
			</a>
		</figure>
	<?php endif; ?>
</article>
