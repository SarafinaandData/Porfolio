<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php $sticky = get_theme_mod( 'header_sticky' ); ?>

<div id="page">
	<header class="header <?php echo $sticky ? 'header-fixed' : ''; ?>">

		<div id="mobilemenu"></div>

		<div class="header-bar">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="header-bar-wrap">
							<div class="header-bar-left">
								<a href="#mobilemenu" class="mobile-nav-trigger"><i class="fas fa-bars"></i></a>

								<?php if ( get_theme_mod( 'header_logo' ) ) : ?>
									<div class="site-logo">
										<?php if ( function_exists( 'the_custom_logo' ) ) {
											the_custom_logo();
										} ?>

										<?php if ( get_theme_mod( 'logo_site_title', 1 ) ) : ?>
											<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo-textual">
												<?php bloginfo( 'name' ); ?>
											</a>
										<?php endif; ?>
									</div>
								<?php endif; ?>

								<nav class="nav">
									<?php wp_nav_menu( array(
										'theme_location' => 'main_menu',
										'fallback_cb'    => 'brittany_main_menu_fallback',
										'container'      => '',
										'menu_id'        => '',
										'menu_class'     => 'navigation',
									) ); ?>
								</nav><!-- #nav -->
							</div>

							<div class="header-bar-right">
								<?php if ( get_theme_mod( 'header_cart', 1 ) ) : ?>
									<?php if ( class_exists( 'WooCommerce' ) ) : ?>
										<div class="cart-dropdown">
											<a href="#" class="cart-dropdown-toggle">
												<i class="fas fa-shopping-cart"></i>
												<?php if ( ! WC()->cart->is_empty() ) : ?>
													<i class="ci-badge"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></i>
												<?php endif; ?>
											</a>

											<div class="cart-dropdown-content">
												<div class="cart-dropdown-content-wrap">
													<div class="widget_shopping_cart_content">
														<?php woocommerce_mini_cart(); ?>
													</div>
												</div>
											</div>
										</div>
									<?php endif; ?>
								<?php endif; ?>


								<?php if ( get_theme_mod( 'header_socials', 1 ) ) {
									get_template_part( 'part-social-icons' );
								} ?>

								<?php if ( get_theme_mod( 'header_search', 1 ) ) : ?>
									<a href="#" class="main-search-trigger"><i class="fas fa-search"></i></a>
								<?php endif; ?>
							</div>
						</div>

						<?php if ( get_theme_mod( 'header_search', 1 ) ) : ?>
							<div class="header-search-wrap">
								<form action="<?php echo esc_url( home_url( '/' ) ); ?>" class="searchform-header">
									<label class="sr-only" for="header-search"><?php esc_html_e( 'Search for:', 'brittany' ); ?></label>
									<input type="search" id="header-search" name="s" value="" placeholder="<?php echo esc_attr_x( 'Enter your search and hit return', 'search box placeholder', 'brittany' ); ?>">
								</form>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>

		<?php if ( ! get_theme_mod( 'header_logo' ) && ! ( is_page_template( 'template-frontpage-fullscreen-slider.php' ) || is_page_template( 'template-frontpage-fullwidth-slider.php' ) ) ) : ?>
			<div class="logo-wrap">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="site-logo">
								<?php if ( function_exists( 'the_custom_logo' ) ) {
									the_custom_logo();
								} ?>

								<?php if ( get_theme_mod( 'logo_site_title', 1 ) ) : ?>
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo-textual">
										<?php bloginfo( 'name' ); ?>
									</a>
								<?php endif; ?>
							</div>

							<?php if ( get_bloginfo( 'description' ) && get_theme_mod( 'logo_tagline', 1 ) ) : ?>
								<p class="site-tagline"><?php bloginfo( 'description' ); ?></p>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</header>
