<div class="entry-section">
	<h3 class="section-title"><?php esc_html_e( 'About Me', 'brittany' ); ?></h3>

	<div class="entry-author-box">
		<figure class="entry-author-image">
			<?php echo get_avatar( get_the_author_meta( 'ID' ), 110, 'avatar_default', esc_attr( get_the_author_meta( 'display_name' ) ), array( 'extra_attr' => 'itemprop="image"' ) ); ?>
		</figure>

		<div class="entry-author-info">
			<h5><?php the_author(); ?></h5>

			<?php echo wp_kses( get_the_author_meta( 'description' ), brittany_get_allowed_tags() ); ?>

			<?php get_template_part( 'part-authorbox-social-icons' ); ?>
		</div>
	</div>
</div>
