<?php

add_action( 'after_setup_theme', 'brittany_woocommerce_setup' );
if ( ! function_exists( 'brittany_woocommerce_setup' ) ) :
function brittany_woocommerce_setup() {
	// Let WooCommerce know that we support it.
	add_theme_support( 'woocommerce', array(
		'thumbnail_image_width'         => 750,
		'single_image_width'            => 750,
		'gallery_thumbnail_image_width' => 200,
		'product_grid'                  => array(
			'default_columns' => 2,
			'min_columns'     => 1,
			'max_columns'     => 4,
		),
	) );

	if ( class_exists( 'WooCommerce' ) ) {
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-slider' );

		//Change the aspect ratio of product gallery images.
		add_filter( 'woocommerce_get_image_size_gallery_thumbnail', 'brittany_woocommerce_gallery_thumb_size' );
		function brittany_woocommerce_gallery_thumb_size() {
			return array(
				'width'  => 150,
				'height' => 0,
				'crop'   => 0,
			);
		}

		// Skip the default woocommerce styling and use our boilerplate.
		// Also deregister unnecessary other styles and scripts
		if ( ! function_exists( 'ci_deregister_woocommerce_styles' ) ) {
			function ci_deregister_woocommerce_styles() {
				wp_deregister_style( 'woocommerce-general' );
				wp_deregister_style( 'flexslider' );
			}

			add_filter( 'woocommerce_enqueue_styles', 'ci_deregister_woocommerce_styles' );
		}

		// Remove breadcrumbs.
		remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

		// Remove result count, e.g. "Showing 1–10 of 22 results", added manually
		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );

		add_action( 'woocommerce_before_shop_loop', 'brittany_woocommerce_shop_actions', 20 );
		if ( ! function_exists( 'brittany_woocommerce_shop_actions' ) ) :
		function brittany_woocommerce_shop_actions() {
			?>
			<div class="actions">

				<?php woocommerce_result_count(); ?>

				<?php
					$first  = absint( apply_filters( 'brittany_products_view_first', 25 ) );
					$second = absint( apply_filters( 'brittany_products_view_second', 50 ) );

					$url = get_permalink( wc_get_page_id( 'shop' ) );
					if ( is_product_taxonomy() ) {
						$url = get_term_link( get_queried_object_id() );
					} elseif ( is_post_type_archive( 'product' ) ) {
						$url = get_post_type_archive_link( 'product' );
					}
				?>
				<div class="product-number">
					<span><?php esc_html_e( 'View:', 'brittany' ); ?></span>
					<a href="<?php echo esc_url( add_query_arg( 'view', $first, $url ) ); ?>"><?php echo esc_html( $first ); ?></a>
					<a href="<?php echo esc_url( add_query_arg( 'view', $second, $url ) ); ?>"><?php echo esc_html( $second ); ?></a>
					<?php if ( apply_filters( 'brittany_products_view_all', true ) ) : ?>
						<a href="<?php echo esc_url( add_query_arg( 'view', 'all', $url ) ); ?>"><?php esc_html_e( 'All', 'brittany' ); ?></a>
					<?php endif; ?>
				</div>

			</div><!-- .actions -->
			<?php
		}
		endif;

		if ( isset( $_GET['view'] ) ) {
			// This check is needed, as WooCommerce hides the "Rows per page" option if there are functions hooked to 'loop_shop_per_page'.
			add_filter( 'loop_shop_per_page', 'brittany_woocommerce_loop_shop_per_page_view' );
		}

		function brittany_woocommerce_loop_shop_per_page_view( $posts_per_page ) {

			if ( empty( $_GET['view'] ) ) {
				return $posts_per_page;
			}

			if ( 'all' === $_GET['view'] ) {
				$view = - 1;
			} else {
				$view = absint( $_GET['view'] );
			}

			$first  = absint( apply_filters( 'brittany_products_view_first', 25 ) );
			$second = absint( apply_filters( 'brittany_products_view_second', 50 ) );

			$valid_values = array( $posts_per_page );

			if ( $first ) {
				$valid_values[] = $first;
			}

			if ( $second ) {
				$valid_values[] = $second;
			}

			if ( apply_filters( 'brittany_products_view_all', true ) ) {
				$valid_values[] = -1;
			}

			if ( in_array( $view, $valid_values, true ) ) {
				return $view;
			}

			return $posts_per_page;
		}

		add_filter( 'term_link', 'brittany_woocommerce_term_link', 10, 3 );
		function brittany_woocommerce_term_link( $termlink, $term, $taxonomy ) {
			if ( ! in_array( $taxonomy, get_object_taxonomies( 'product' ), true ) ) {
				return $termlink;
			}

			$default_posts_per_page = (int) wc_get_default_products_per_row() * wc_get_default_product_rows_per_page();
			$user_posts_per_page    = (int) brittany_woocommerce_loop_shop_per_page_view( $default_posts_per_page );

			if ( - 1 === $user_posts_per_page ) {
				$user_posts_per_page = 'all';
			}

			if ( $default_posts_per_page !== $user_posts_per_page ) {
				$termlink = add_query_arg( 'view', $user_posts_per_page, $termlink );
			}

			return $termlink;
		}


		// Change number of columns in product loop
		// add_filter( 'loop_shop_columns', 'brittany_woocommerce_loop_show_columns' );
		if ( ! function_exists( 'brittany_woocommerce_loop_show_columns' ) ) :
		function brittany_woocommerce_loop_show_columns() {
			return 2;
		}
		endif;


		// Remove the link that surrounds the product and category in shop loop.
		remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );

		// We don't need the Rating and Add to Cart button in the listing.
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );

		// Move the product thumbnail from woocommerce_before_shop_loop_item_title to woocommerce_before_shop_loop_item
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
		add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_thumbnail', 10 );

		// Remove sale flash. It is called directly within woocommerce_template_loop_product_thumbnail()
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );

		// Move price from woocommerce_after_shop_loop_item_title to woocommerce_before_shop_loop_item_title
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
		add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );


		// Move the link that surrounds the category in shop loop, to wrap the thumbnail instead.
		remove_action( 'woocommerce_before_subcategory', 'woocommerce_template_loop_category_link_open', 10 );
		remove_action( 'woocommerce_after_subcategory', 'woocommerce_template_loop_category_link_close', 10 );
		add_action( 'woocommerce_before_subcategory_title', 'woocommerce_template_loop_category_link_open', 5 );
		add_action( 'woocommerce_before_subcategory_title', 'woocommerce_template_loop_category_link_close', 15 );

		// Remove star rating.
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );

		// Move meta above the title.
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
		add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 3 );

		// Show tags after the Add to Cart button (they are removed from the template file).
		add_action( 'woocommerce_single_product_summary', 'brittany_woocommerce_single_product_tags', 40 );

		// Move cross sell display from collaterals to right after the table.
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
		add_action( 'woocommerce_after_cart_table', 'woocommerce_cross_sell_display' );

		add_filter( 'woocommerce_cross_sells_total', 'brittany_woocommerce_cross_sells_columns' );
		add_filter( 'woocommerce_cross_sells_columns', 'brittany_woocommerce_cross_sells_columns' );
		if ( ! function_exists( 'brittany_woocommerce_cross_sells_columns' ) ) :
		function brittany_woocommerce_cross_sells_columns( $posts_per_page ) {
			return 3;
		}
		endif;



		// Override the product thumbnail hooked function, as we want to change its output.
		if ( ! function_exists( 'woocommerce_template_loop_product_thumbnail' ) ) :
		function woocommerce_template_loop_product_thumbnail() {
			?>
			<figure class="entry-item-thumb">
				<a href="<?php the_permalink(); ?>">
					<?php echo woocommerce_get_product_thumbnail(); ?>
				</a>

				<?php woocommerce_show_product_sale_flash(); ?>
			</figure>
		<?php
		}
		endif;


		if ( ! function_exists( 'woocommerce_template_loop_product_title' ) ) :
		function woocommerce_template_loop_product_title() {
			?>
			<h2 class="entry-item-title">
				<a href="<?php the_permalink(); ?>">
					<?php the_title(); ?>
				</a>
			</h2>
			<?php
		}
		endif;


		if ( ! function_exists( 'woocommerce_template_loop_category_title' ) ) :
		function woocommerce_template_loop_category_title( $category ) {
			?>
			<div class="entry-item-content-wrap">
				<div class="entry-item-content">
					<h2 class="entry-item-title">
						<a href="<?php echo esc_url( get_term_link( $category->slug, 'product_cat' ) ); ?>">
							<?php
								echo $category->name;

								if ( $category->count > 0 )
									echo apply_filters( 'woocommerce_subcategory_count_html', ' <span class="count">(' . $category->count . ')</span>', $category );
							?>
						</a>
					</h2>
				</div>
			</div>
			<?php
		}
		endif;


		// Make some WooCommerce pages get the fullwidth template
		add_filter( 'template_include', 'brittany_woocommerce_cart_fullwidth' );
		if ( ! function_exists( 'brittany_woocommerce_cart_fullwidth' ) ) :
		function brittany_woocommerce_cart_fullwidth( $template ) {
			$filename = 'template-fullwidth.php';
			$located  = '';
			if ( file_exists( get_stylesheet_directory() . '/' . $filename ) ) {
				$located = get_stylesheet_directory() . '/' . $filename;
			} elseif ( file_exists( get_template_directory() . '/' . $filename ) ) {
				$located = get_template_directory() . '/' . $filename;
			} else {
				$located = '';
			}

			if ( ! empty( $located ) && ( is_cart() || is_checkout() || is_account_page() ) ) {
				return $located;
			}

			return $template;
		}
		endif;

		if ( ! function_exists( 'brittany_woocommerce_single_product_tags' ) ) :
		function brittany_woocommerce_single_product_tags() {
			global $post, $product;

			$tags      = get_the_terms( $post->ID, 'product_tag' );
			$tag_count = 0;
			if ( is_array( $tags ) ) {
				$tag_count = count( $tags );
			}

			?><div class="product_meta"><?php
				echo wc_get_product_tag_list( $product->get_ID(), ', ', '<span class="tagged_as">' . _n( 'Tag:', 'Tags:', $tag_count, 'brittany' ) . ' ', '</span>' );
			?></div><?php
		}
		endif;

		// Change posts_per_page on related products
		add_filter( 'woocommerce_output_related_products_args', 'ci_output_related_products_args' );
		if ( ! function_exists( 'ci_output_related_products_args' ) ) :
		function ci_output_related_products_args( $args ) {
			$args['posts_per_page'] = 4;
			$args['columns']        = 2;
			return $args;
		}
		endif;

		// Change columns on upsell products
		add_filter( 'woocommerce_upsells_columns', 'ci_woocommerce_up_sells_columns' );
		if ( ! function_exists( 'ci_woocommerce_up_sells_columns' ) ) :
		function ci_woocommerce_up_sells_columns( $columns ) {
			$columns = 2;

			return $columns;
		}
		endif;

		// Change posts_per_page on upsell products
		add_filter( 'woocommerce_upsells_total', 'ci_woocommerce_upsells_total' );
		if ( ! function_exists( 'ci_woocommerce_upsells_total' ) ) :
		function ci_woocommerce_upsells_total( $limit ) {
			$limit = 4;

			return $limit;
		}
		endif;

		// Change posts_per_page on cross sells
		add_filter( 'woocommerce_cross_sells_total', 'ci_woocommerce_cross_sells_total' );
		if ( ! function_exists( 'ci_woocommerce_cross_sells_total' ) ) :
		function ci_woocommerce_cross_sells_total( $limit ) {
			$limit = 2;

			return $limit;
		}
		endif;

		add_action( 'woocommerce_before_add_to_cart_quantity', 'brittany_display_quantity_minus' );
		/**
		 * Add minus button before the quantity input.
		 */
		function brittany_display_quantity_minus() {
			echo '<div class="quantity-wrap"><button type="button" class="qty-btn qty-minus">-</button>';
		}

		add_action( 'woocommerce_after_add_to_cart_quantity', 'brittany_display_quantity_plus' );
		/**
		 * Add plus button after the quantity input.
		 */
		function brittany_display_quantity_plus() {
			echo '<button type="button" class="qty-btn qty-plus" >+</button></div>';
		}

	}

}
endif;
