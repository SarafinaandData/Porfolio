<?php
namespace Elementor;

class Widget_Post_Type extends Widget_Base {

	public function get_name() {
		return 'post_type_widget';
	}

	public function get_title() {
		return __( 'Brittany Post Type', 'brittany' );
	}

	public function get_icon() {
		return 'eicon-wordpress';
	}

	public function get_categories() {
		return [ 'brittany-elements' ];
	}



	protected function _register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Brittany Post Type', 'brittany' ),
			]
		);

		$this->add_control(
			'html_msg',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Display any post type item from Brittany by selecting it from the list.', 'brittany' ),
				'content_classes' => 'ci-description',
			]
		);

		$this->add_control(
			'post_type',
			[
				'label'   => __( 'Post Type', 'brittany' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => element_post_types(),
			]
		);

		foreach ( element_post_types() as $slug => $name ) {
			$this->add_control(
				'selected_post_' . $slug,
				[
					'label'       => __( 'Post', 'brittany' ),
					'type'        => Controls_Manager::SELECT,
					'default'     => '',
					'label_block' => true,
					'options'     => get_all_post_type_items( $slug ),
					'condition'   => [
						'post_type' => $slug,
					],
				]
			);
		}

		$this->add_control(
			'layout',
			[
				'label'       => __( 'Layout', 'brittany' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'label_block' => true,
				'options'     => element_layouts(),
			]
		);

		$this->add_control(
			'view',
			[
				'label'   => __( 'View', 'brittany' ),
				'type'    => Controls_Manager::HIDDEN,
				'default' => 'traditional',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_title',
			[
				'label' => __( 'Title Styles', 'brittany' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_text_color',
			[
				'label'     => __( 'Text Color', 'brittany' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1f1f1f',
				'selectors' => [
					'{{WRAPPER}} .entry-item-title a' => 'color: {{VALUE}};',
				],
				'scheme'    => [
					'type'  => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_text_typography',
				'scheme'   => Scheme_Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .entry-item-title a',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_text',
			[
				'label' => __( 'Text Styles', 'brittany' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_color',
			[
				'label'     => __( 'Text Color', 'brittany' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1f1f1f',
				'selectors' => [
					'{{WRAPPER}} .entry-item-excerpt' => 'color: {{VALUE}};',
				],
				'scheme'    => [
					'type'  => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'text_typography',
				'scheme'   => Scheme_Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .entry-item-excerpt',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_meta',
			[
				'label' => __( 'Meta Styles', 'brittany' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'meta_text_color',
			[
				'label'     => __( 'Text Color', 'brittany' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#5c5c5c',
				'selectors' => [
					'{{WRAPPER}} .entry-meta, {{WRAPPER}} .entry-item-categories a, {{WRAPPER}} .entry-item-sharing a' => 'color: {{VALUE}};',
				],
				'scheme'    => [
					'type'  => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'meta_text_typography',
				'scheme'   => Scheme_Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .entry-meta, {{WRAPPER}} .entry-item-categories a, {{WRAPPER}} .entry-item-sharing a',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_button',
			[
				'label' => __( 'Accent', 'brittany' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'accent_color',
			[
				'label'     => __( 'Accent Color', 'brittany' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#eb5b75',
				'selectors' => [
					'{{WRAPPER}} .entry-item-title a:hover, {{WRAPPER}} .entry-item-categories a:hover, {{WRAPPER}} .entry-item-sharing a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings   = $this->get_settings();
		$post_type  = $settings['post_type'];
		$layout     = $settings['layout'];
		$post_id_bc = isset( $settings['selected_post'] ) ? $settings['selected_post'] : false;
		$post_id    = $settings[ 'selected_post_' . $post_type ] ? $settings[ 'selected_post_' . $post_type ] : $post_id_bc;

		if ( empty( $post_id ) ) {
			return;
		}

		$q = new \WP_Query(
			array(
				'post_type' => get_post_type( $post_id ),
				'p'         => $post_id,
			)
		);

		while ( $q->have_posts() ) :
			$q->the_post();

			if ( ! empty( $layout ) ) {
				get_template_part( "item-{$layout}", get_post_type() );
			} else {
				get_template_part( 'item', get_post_type() );
			}

		endwhile;

		wp_reset_postdata();

	}

}
