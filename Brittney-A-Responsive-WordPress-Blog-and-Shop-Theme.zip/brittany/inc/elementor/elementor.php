<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'elementor/init', 'Elementor\brittany_elements_init' );
function brittany_elements_init() {
	Plugin::instance()->elements_manager->add_category(
		'brittany-elements',
		[
			'title' => __( 'Brittany Elements', 'brittany' ),
			'icon'  => 'font',
		],
		1
	);
}

add_action( 'elementor/widgets/widgets_registered', 'Elementor\add_brittany_elements' );
function add_brittany_elements() {
	require_once get_theme_file_path( '/inc/elementor/brittany-post-type-element.php' );
	Plugin::instance()->widgets_manager->register_widget_type( new Widget_Post_Type() );
}

function get_all_post_type_items( $post_type = 'post' ) {
	$posts_args = array(
		'post_type'      => $post_type,
		'post_status'    => 'publish',
		'posts_per_page' => '-1',
	);

	$posts = new \WP_Query( $posts_args );

	$post_list = wp_list_pluck( $posts->posts, 'post_title', 'ID' );

	return $post_list;
}

/**
 * Get All Post Types
 *
 * @return array
 */
function element_post_types() {
	$cpts = get_post_types(
		array(
			'public'            => true,
			'show_in_nav_menus' => true,
			'show_ui'           => true,
		),
		'object'
	);

	$excluded_cpts = apply_filters( 'brittany_plugin_element_excluded_cpts', array( 'elementor_library', 'attachment' ) );

	foreach ( $excluded_cpts as $excluded_cpt ) {
		unset( $cpts[ $excluded_cpt ] );
	}

	$post_types = array_merge( $cpts );

	$types = wp_list_pluck( $post_types, 'label', 'name' );

	return $types;
}

/**
 * Element Layouts
 *
 * @return array
 */
function element_layouts() {
	$element_layouts = brittany_get_blog_post_layout_choices();

	unset( $element_layouts['horizontal-alt'] );
	unset( $element_layouts['horizontal-fixed-alt'] );

	return $element_layouts;
}