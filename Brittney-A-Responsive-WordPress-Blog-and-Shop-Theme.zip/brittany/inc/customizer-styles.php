<?php
add_action( 'wp_head', 'brittany_customizer_css' );
if( ! function_exists( 'brittany_customizer_css' ) ):
function brittany_customizer_css() {
	?><style type="text/css"><?php

	//
	// Logo
	//
	if ( get_theme_mod( 'logo_padding_top' ) || get_theme_mod( 'logo_padding_bottom' ) ) {
		?>
		.site-logo {
			<?php if ( get_theme_mod( 'logo_padding_top' ) ) : ?>
				padding-top: <?php echo intval( get_theme_mod( 'logo_padding_top' ) ); ?>px;
			<?php endif; ?>
			<?php if ( get_theme_mod( 'logo_padding_bottom' ) ) : ?>
				padding-bottom: <?php echo intval( get_theme_mod( 'logo_padding_bottom' ) ); ?>px;
			<?php endif; ?>
		}
		<?php
	}

	//
	// Global Colors
	//
	if ( get_theme_mod( 'global_secondary_bg_color' ) ) {
		?>
		input,
		textarea,
		.images > a img,
		.footer,
		.header-bar,
		.header-bar-wrap,
		.searchform-header,
		.cart-dropdown-content-wrap,
		.entry-item-content-wrap,
		.entry-item-media:hover .entry-item-media-content,
		.entry-thumb,
		.entry-content img,
		#paging a:hover,
		#paging .current,
		.searchform,
		.newsletter-form,
		.widget-about .widget-about-avatar img,
		.social-icon:hover,
		.wp-caption,
		.navigation a {
			background-color: <?php echo get_theme_mod( 'global_secondary_bg_color' ); ?>;
		}

		.entry-item::after,
		.entry-item-fixed,
		section.widget .instagram-pics li a::after {
			border-color: <?php echo get_theme_mod( 'global_secondary_bg_color' ); ?>;
		}

		<?php
	}

	if ( get_theme_mod( 'global_primary_color' ) ) {
		?>
		a, a:hover,
		.item-title a:hover,
		.btn:hover,
		input[type="button"]:hover,
		input[type="submit"]:hover,
		input[type="reset"]:hover,
		button:hover,
		.comment-author a:hover,
		.comment-metadata a:hover,
		.main-search-trigger:hover,
		.entry-item-title:hover a,
		.entry-item-categories a:hover,
		.entry-item-sharing a:hover,
		.entry-slide-control a:hover,
		.entry-title:hover a,
		.entry-meta a:hover,
		.entry-content blockquote::before,
		.row-table-left a:not(.btn):hover,
		.row-table-right a:not(.btn):hover,
		#paging a:hover,
		#paging .current,
		.navigation > li > a:hover,
		.navigation > li.sfHover > a,
		.navigation > li.sfHover > a:active,
		.navigation > li.current_page_item > a,
		.navigation > li.current-menu-item > a,
		.navigation > li.current-menu-ancestor > a,
		.navigation > li.current-menu-parent > a,
		.navigation > li.current > a,
		.navigation > li ul a:hover,
		.navigation > li ul .sfHover > a,
		.social-icon:hover,
		.select2-container.select2-container--default .select2-results__option--highlighted[data-selected] {
			color: <?php echo get_theme_mod( 'global_primary_color' ); ?>;
		}

		.btn,
		input[type="button"],
		input[type="submit"],
		input[type="reset"],
		button,
		.woocommerce-message,
		.woocommerce-error,
		.woocommerce-info,
		.woocommerce-noreviews,
		.onsale,
		.woocommerce-product-gallery__trigger,
		.product .summary ul li:before,
		.shop_attributes th:first-child:before,
		.cart-dropdown:hover .cart-dropdown-toggle,
		.cart-dropdown.cart-dropdown-open .cart-dropdown-toggle,
		.ci-badge,
		.qty-btn:hover,
		.price_slider .ui-slider-handle {
			background-color: <?php echo get_theme_mod( 'global_primary_color' ); ?>;
		}

		.cart-dropdown.cart-dropdown-open .cart-dropdown-toggle .ci-badge,
		.cart-dropdown:hover .cart-dropdown-toggle .ci-badge {
			border-color: <?php echo get_theme_mod( 'global_primary_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'global_text_color' ) ) {
		$text_color       = get_theme_mod( 'global_text_color' );
		$text_color_light = brittany_hex2rgba( $text_color, 0.65 );
		?>
		body,
		.comment-author a,
		.comment-metadata a,
		.form-allowed-tags,
		.comment-notes,
		.woocommerce-tabs .tabs li a,
		.shop_table .product-remove .remove,
		.widget .instagram-pics li a,
		.site-logo a,
		.mobile-nav-trigger:hover,
		.mobile-nav-trigger:active,
		.section-title label,
		.entry-item-title a,
		.entry-title a,
		#paging a,
		#paging > span,
		#paging li span,
		.navigation a,
		.widget-title label,
		.woocommerce-MyAccount-navigation-link.is-active a {
			color: <?php echo $text_color; ?>;
		}

		.main-search-trigger,
		.cart-dropdown:hover .cart-dropdown-toggle .ci-badge,
		.cart-dropdown.cart-dropdown-open .cart-dropdown-toggle .ci-,
		.cart-dropdown-toggle,
		.mobile-nav-trigger,
		.entry-item-sharing a,
		.entry-slide-control a,
		.entry-meta a,
		.row-table-right a,
		.social-icon,
		.wp-caption .wp-caption-text,
		blockquote cite,
		label,
		.comment-author,
		.comment-metadata,
		.product_meta,
		.product .summary .stock,
		.shop_table th,
		.cart_totals table th,
		.cart_totals table td,
		.price_slider_wrapper,
		.price_slider_amount,
		.site-tagline,
		.section-title small,
		.entry-item-categories a,
		.entry-meta,
		.row-table-left a:not(.btn) {
			color: <?php echo $text_color_light; ?>;
		}

		.qty-btn {
			background-color: <?php echo $text_color; ?>;
		}

		::-webkit-input-placeholder { color: <?php echo $text_color_light; ?>; }
		:-moz-placeholder           { color: <?php echo $text_color_light; ?>; }
		::-moz-placeholder          { color: <?php echo $text_color_light; ?>; }
		:-ms-input-placeholder      { color: <?php echo $text_color_light; ?>; }
		<?php
	}

	if ( get_theme_mod( 'global_link_color' ) ) {
		?>
		.entry-content a,
		.entry-content a:hover {
			color: <?php echo get_theme_mod( 'global_link_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'global_link_hover_color' ) ) {
		?>
		.entry-content a:hover {
			color: <?php echo get_theme_mod( 'global_link_hover_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'global_btn_text_color' ) ) {
		?>
		.btn,
		input[type="button"],
		input[type="submit"],
		input[type="reset"],
		button,
		.sidebar .button,
		.sidebar .btn,
		.comment-reply-link {
			color: <?php echo get_theme_mod( 'global_btn_text_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'global_btn_bg_color' ) ) {
		?>
		.btn,
		input[type="button"],
		input[type="submit"],
		input[type="reset"],
		button,
		.comment-reply-link {
			background-color: <?php echo get_theme_mod( 'global_btn_bg_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'global_btn_hover_bg_color' ) ) {
		?>
		.btn:hover,
		input[type="button"]:hover,
		input[type="submit"]:hover,
		input[type="reset"]:hover,
		button:hover,
		.comment-reply-link:hover{
			background-color: <?php echo get_theme_mod( 'global_btn_hover_bg_color' ); ?>;

			<?php if ( get_theme_mod( 'global_btn_text_color' ) ) { ?>
				color: <?php echo get_theme_mod( 'global_btn_bg_color' ); ?>
			<?php } ?>
		}
		<?php
	}

	if ( get_theme_mod( 'global_border_color' ) ) {
		$border_color = get_theme_mod( 'global_border_color' );
		?>
		input,
		textarea,
		select,
		.payment_box,
		.myaccount_user,
		.woocommerce fieldset,
		.searchform,
		.cart-dropdown-content-wrap,
		.entry-item-fixed:hover .entry-item-content-wrap,
		.row-table,
		#paging a,
		#paging > span,
		#paging li span,
		.social-icon,
		.select2-container.select2-container--default .select2-selection--single,
		.select2-container.select2-container--default .select2-search--dropdown .select2-search__field,
		.select2-container.select2-container--default .select2-dropdown {
			border-color: <?php echo $border_color; ?>;
		}

		#comments h2,
		#comments h3,
		.woocommerce-tabs,
		.shop_attributes tr:first-child th,
		.shop_attributes tr:first-child td,
		#order_review_heading,
		.widget_shopping_cart_content .total,
		.footer,
		.section-title,
		.entry-item-footer,
		.navigation ul ul,
		.widget-title {
			border-top-color: <?php echo $border_color; ?>;
		}

		.shop-actions,
		.product .summary ul li,
		.product .summary ul li:first-child,
		.woocommerce-tabs,
		.woocommerce-tabs .tabs li,
		.woocommerce-tabs .pane-container,
		.woocommerce-tabs .panel #tab-reviews #reply-title,
		.shop_attributes th,
		.shop_attributes td,
		.shop_table th,
		.shop_table td,
		.cart_totals h2,
		.cart_totals table th,
		.cart_totals table td,
		.shipping-calculator-button,
		.woocommerce form.login .lost_password a,
		.payment_methods li,
		.widget_shopping_cart_content .total,
		.header-bar,
		.entry-item-content-wrap,
		.navigation > li ul a,
		.widget_recent_comments ul li,
		.woocommerce-MyAccount-navigation-link a {
			border-bottom-color: <?php echo $border_color; ?>;
		}

		.header-bar-right,
		.main-search-trigger,
		.mobile-nav-trigger,
		.entry-item-content-wrap,
		.navigation > li > a,
		.navigation ul {
			border-right-color: <?php echo $border_color; ?>;
		}

		.header-bar-right,
		.main-search-trigger,
		.cart-dropdown-toggle,
		.mobile-nav-trigger,
		.entry-item-content-wrap,
		.entry-item-categories + .entry-item-sharing,
		.entry-item-title + .entry-item-sharing,
		.entry-slide-control,
		.entry-slide-control .entry-slide-next,
		.row-table-left + .row-table-right,
		#paging > a:not(.page-numbers):nth-child(2),
		.nav,
		.navigation ul {
			border-left-color: <?php echo $border_color; ?>;
		}

		.product .summary .group_table {
			background-color: <?php brittany_hex2rgba( $border_color, 0.3 ); ?>;
		}

		@media ( min-width: 768px ) {
			.entry-item-horizontal .entry-item-content-wrap {
				border-top-color: <?php echo $border_color; ?>;
			}
		}
		<?php
	}

	//
	// Header
	//
	if ( get_theme_mod( 'header_bg_color' ) ) {
		?>
		.header-bar-wrap,
		.cart-dropdown-content-wrap,
		.searchform-header,
		.header-bar,
		.navigation a,
		.header .social-icon:hover {
			background-color: <?php echo get_theme_mod( 'header_bg_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'header_text_color' ) ) {
		?>
		.header a,
		.navigation a  {
			color: <?php echo get_theme_mod( 'header_text_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'header_hover_color' ) ) {
		?>
		.header a:hover,
		.navigation > li > a:hover,
		.navigation > li.sfHover > a,
		.navigation > li.sfHover > a:active,
		.navigation > li.current_page_item > a,
		.navigation > li.current-menu-item > a,
		.navigation > li.current-menu-ancestor > a,
		.navigation > li.current-menu-parent > a,
		.navigation > li.current > a,
		.navigation > li ul a:hover,
		.navigation > li ul .sfHover > a{
			color: <?php echo get_theme_mod( 'header_hover_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'header_border_color' ) ) {
		?>
		.searchform-header,
		.header .social-icon,
		.header input {
			border-color: <?php echo get_theme_mod( 'header_border_color' ); ?>;
		}

		.navigation ul ul {
			border-top-color: <?php echo get_theme_mod( 'header_border_color' ); ?>;
		}

		.navigation > li ul a,
		.header-bar {
			border-bottom-color: <?php echo get_theme_mod( 'header_border_color' ); ?>;
		}

		.nav,
		.navigation ul,
		.main-search-trigger,
		.cart-dropdown-toggle,
		.mobile-nav-trigger {
			border-left-color: <?php echo get_theme_mod( 'header_border_color' ); ?>;
		}

		.navigation > li a,
		.navigation ul,
		.header-bar-right,
		.main-search-trigger,
		.header-bar-right {
			border-right-color: <?php echo get_theme_mod( 'header_border_color' ); ?>;
		}
		<?php
	}

	//
	// Sidebar
	//
	if ( get_theme_mod( 'sidebar_bg_color' ) ) {
		?>
		.sidebar {
			padding: 15px;
			background-color: <?php echo get_theme_mod( 'sidebar_bg_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'sidebar_text_color' ) ) {
		?>
		.sidebar {
			color: <?php echo get_theme_mod( 'sidebar_text_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'sidebar_link_color' ) ) {
		?>
		.sidebar a,
		.sidebar a:hover {
			color: <?php echo get_theme_mod( 'sidebar_link_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'sidebar_hover_color' ) ) {
		?>
		.sidebar a:hover {
			color: <?php echo get_theme_mod( 'sidebar_hover_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'sidebar_title_color' ) ) {
		?>
		.sidebar .widget-title {
			color: <?php echo get_theme_mod( 'sidebar_title_color' ); ?>;
		}
		<?php
	}

	if ( get_theme_mod( 'sidebar_border_color' ) ) {
		?>
		.sidebar input,
		.sidebar textarea {
			border-color: <?php echo get_theme_mod( 'sidebar_border_color' ); ?>;
		}

		.widget-title {
			border-top-color: <?php echo get_theme_mod( 'sidebar_border_color' ); ?>;
		}
		<?php
	}

	//
	// Typography
	//
	if ( get_theme_mod( 'h1_size' ) ) {
		?>
		h1 {
			font-size: <?php echo get_theme_mod( 'h1_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'h2_size' ) ) {
		?>
		h2 {
			font-size: <?php echo get_theme_mod( 'h2_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'h3_size' ) ) {
		?>
		h3 {
			font-size: <?php echo get_theme_mod( 'h3_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'h4_size' ) ) {
		?>
		h4 {
			font-size: <?php echo get_theme_mod( 'h4_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'h5_size' ) ) {
		?>
		h5 {
			font-size: <?php echo get_theme_mod( 'h5_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'h6_size' ) ) {
		?>
		h6 {
			font-size: <?php echo get_theme_mod( 'h6_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'body_text_size' ) ) {
		?>
		body,
		.entry-content {
			font-size: <?php echo get_theme_mod( 'body_text_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'widgets_text_size' ) ) {
		?>
		.sidebar .widget {
			font-size: <?php echo get_theme_mod( 'widgets_text_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'widgets_title_size' ) ) {
		?>
		.widget-title {
			font-size: <?php echo get_theme_mod( 'widgets_title_size' ); ?>px;
		}
		<?php
	}

	if ( get_theme_mod( 'lowercase_widget_titles' ) ) {
		?>
		.widget-title,
		.section-title {
			text-transform: none;
		}
		<?php
	}

	if ( get_theme_mod( 'lowercase_content_headings' ) ) {
		?>
		.entry-content h1,
		.entry-content h2,
		.entry-content h3,
		.entry-content h4,
		.entry-content h5,
		.entry-content h6 {
			text-transform: none;
		}
		<?php
	}

	?></style><?php
}
endif;
