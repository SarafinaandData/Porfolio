<?php
add_action( 'customize_register', 'brittany_customize_register', 100 );
/**
 * Registers all theme-related options to the Customizer.
 *
 * @param WP_Customize_Manager $wpc Reference to the customizer's manager object.
 */
function brittany_customize_register( $wpc ) {

	$wpc->add_section( 'header', array(
		'title'    => esc_html_x( 'Header Options', 'customizer section title', 'brittany' ),
		'priority' => 1,
	) );

	$wpc->get_panel( 'nav_menus' )->priority = 2;

	$wpc->add_section( 'layout', array(
		'title'    => esc_html_x( 'Layout Options', 'customizer section title', 'brittany' ),
		'priority' => 20,
	) );

	$wpc->add_section( 'homepage', array(
		'title'    => esc_html_x( 'Front Page Carousel', 'customizer section title', 'brittany' ),
		'priority' => 30,
	) );

	$wpc->add_panel( 'theme_colors', array(
		'title'    => esc_html_x( 'Theme Colors', 'customizer section title', 'brittany' ),
		'priority' => 35,
	) );

	$wpc->add_section( 'global_colors', array(
		'title'    => _x( 'Global Colors', 'customizer section title', 'brittany' ),
		'panel'    => 'theme_colors',
		'priority' => 10,
	) );

	$wpc->add_section( 'header_colors', array(
		'title'    => _x( 'Header Colors', 'customizer section title', 'brittany' ),
		'panel'    => 'theme_colors',
		'priority' => 20,
	) );

	$wpc->add_section( 'sidebar_colors', array(
		'title'    => _x( 'Sidebar Colors', 'customizer section title', 'brittany' ),
		'panel'    => 'theme_colors',
		'priority' => 30,
	) );

	$wpc->add_section( 'typography', array(
		'title'    => _x( 'Typography Options', 'customizer section title', 'brittany' ),
		'priority' => 40,
	) );

	// The following line doesn't work in a some PHP versions. Apparently, get_panel( 'widgets' ) returns an array,
	// therefore a cast to object is needed. http://wordpress.stackexchange.com/questions/160987/warning-creating-default-object-when-altering-customize-panels
	//$wpc->get_panel( 'widgets' )->priority = 55;
	$panel_widgets = (object) $wpc->get_panel( 'widgets' );
	$panel_widgets->priority = 55;

	$wpc->add_section( 'social', array(
		'title'       => esc_html_x( 'Social Networks', 'customizer section title', 'brittany' ),
		'description' => esc_html__( 'Enter your social network URLs. Leaving a URL empty will hide its respective icon.', 'brittany' ),
		'priority'    => 60,
	) );

	$wpc->add_section( 'single_post', array(
		'title'       => esc_html_x( 'Posts Options', 'customizer section title', 'brittany' ),
		'description' => esc_html__( 'These options affect your individual posts.', 'brittany' ),
		'priority'    => 70,
	) );

	$wpc->add_section( 'single_page', array(
		'title'       => esc_html_x( 'Pages Options', 'customizer section title', 'brittany' ),
		'description' => esc_html__( 'These options affect your individual pages.', 'brittany' ),
		'priority'    => 80,
	) );

	$wpc->add_section( 'footer', array(
		'title'    => esc_html_x( 'Footer Options', 'customizer section title', 'brittany' ),
		'priority' => 100,
	) );

	// Section 'static_front_page' is not defined when there are no pages.
	if ( get_pages() ) {
		$wpc->get_section( 'static_front_page' )->priority = 110;
	}

	$wpc->add_section( 'other', array(
		'title'       => esc_html_x( 'Other', 'customizer section title', 'brittany' ),
		'description' => esc_html__( 'Other options affecting the whole site.', 'brittany' ),
		'priority'    => 120,
	) );


	//
	// Group options by registering the setting first, and the control right after.
	//

	//
	// Header
	//
	$wpc->add_setting( 'header_sticky', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'header_sticky', array(
		'type'    => 'checkbox',
		'section' => 'header',
		'label'   => esc_html__( 'Enable sticky menu.', 'brittany' ),
	) );

	$wpc->add_setting( 'header_socials', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'header_socials', array(
		'type'    => 'checkbox',
		'section' => 'header',
		'label'   => esc_html__( 'Show social icons.', 'brittany' ),
	) );

	$wpc->add_setting( 'header_search', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'header_search', array(
		'type'    => 'checkbox',
		'section' => 'header',
		'label'   => esc_html__( 'Show search icon.', 'brittany' ),
	) );

	$wpc->add_setting( 'header_cart', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'header_cart', array(
		'type'        => 'checkbox',
		'section'     => 'header',
		'label'       => esc_html__( 'Show shopping cart icon.', 'brittany' ),
		'description' => esc_html__( 'Requires WooCommerce to be installed and active.', 'brittany' ),
	) );

	$wpc->add_setting( 'header_logo', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'header_logo', array(
		'type'        => 'checkbox',
		'section'     => 'header',
		'label'       => esc_html__( 'Inline logo.', 'brittany' ),
		'description' => esc_html__( 'When enabled, the logo will be displayed inline with the main menu. Please note that you will most probably need to change your logo with a smaller version.', 'brittany' ),
	) );

	$wpc->add_setting( 'header_bg_color', array(
		'transport'         => 'postMessage',
		'default'           => '#FFFFFF',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'header_bg_color', array(
		'section' => 'header_colors',
		'label'   => esc_html__( 'Background Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'header_text_color', array(
		'transport'         => 'postMessage',
		'default'           => '#1f1f1f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'header_text_color', array(
		'section' => 'header_colors',
		'label'   => esc_html__( 'Main Text Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'header_hover_color', array(
		'transport'         => 'postMessage',
		'default'           => '#e62d4f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'header_hover_color', array(
		'section' => 'header_colors',
		'label'   => esc_html__( 'Hover/Active Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'header_border_color', array(
		'transport'         => 'postMessage',
		'default'           => '#E6E6E6',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'header_border_color', array(
		'section' => 'header_colors',
		'label'   => esc_html__( 'Border Color', 'brittany' ),
	) ) );



	//
	// Layout
	//
	$wpc->add_setting( 'blog_layout', array(
		'default'           => 'right-sidebar',
		'sanitize_callback' => 'brittany_sanitize_blog_layout_choices',
	) );
	$wpc->add_control( 'blog_layout', array(
		'type'    => 'select',
		'section' => 'layout',
		'label'   => esc_html__( 'Blog page layout', 'brittany' ),
		'choices' => brittany_get_blog_layout_choices(),
	) );

	$wpc->add_setting( 'blog_items_layout', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_blog_post_layout_choices',
	) );
	$wpc->add_control( 'blog_items_layout', array(
		'type'    => 'select',
		'section' => 'layout',
		'label'   => esc_html__( 'Blog posts appearance', 'brittany' ),
		'choices' => brittany_get_blog_post_layout_choices(),
	) );

	$wpc->add_setting( 'blog_columns', array(
		'default'           => 1,
		'sanitize_callback' => 'absint',
	) );
	$wpc->add_control( 'blog_columns', array(
		'type'    => 'select',
		'section' => 'layout',
		'label'   => esc_html__( 'Blog posts columns', 'brittany' ),
		'choices' => array(
			1 => 1,
			2 => 2,
			3 => 3,
			4 => 4,
		),
	) );

	$wpc->add_setting( 'excerpt_length', array(
		'default'           => 55,
		'sanitize_callback' => 'absint',
	) );
	$wpc->add_control( 'excerpt_length', array(
		'type'        => 'number',
		'input_attrs' => array(
			'min'  => 10,
			'step' => 1,
		),
		'section'     => 'layout',
		'label'       => esc_html__( 'Automatically generated excerpt length (in words)', 'brittany' ),
	) );

	$wpc->add_setting( 'excerpt_on_classic_layout', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'excerpt_on_classic_layout', array(
		'type'        => 'checkbox',
		'section'     => 'layout',
		'label'       => esc_html__( 'Show the excerpt.', 'brittany' ),
		'description' => esc_html__( 'Applies only on the Classic blog posts appearance. If unchecked, the content is displayed instead.', 'brittany' ),
	) );

	$wpc->add_setting( 'pagination_method', array(
		'default'           => 'numbers',
		'sanitize_callback' => 'brittany_sanitize_pagination_method',
	) );
	$wpc->add_control( 'pagination_method', array(
		'type'    => 'select',
		'section' => 'layout',
		'label'   => esc_html__( 'Pagination method', 'brittany' ),
		'choices' => array(
			'numbers' => esc_html_x( 'Numbered links', 'pagination method', 'brittany' ),
			'text'    => esc_html_x( '"Previous - Next" links', 'pagination method', 'brittany' ),
		),
	) );



	//
	// Homepage
	//
	$wpc->add_control( new Brittany_Customize_Flexslider_Control( $wpc, 'home_slider', array(
		'section'     => 'homepage',
		'label'       => esc_html__( 'Home Slider', 'brittany' ),
		'description' => esc_html__( 'Fine-tune the homepage slider.', 'brittany' ),
	), array(
		'taxonomy' => 'category',
	) ) );

	$wpc->add_setting( 'home_slider_show_home', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'home_slider_show_home', array(
		'type'    => 'checkbox',
		'section' => 'homepage',
		'label'   => esc_html__( 'Show slider on the front page.', 'brittany' ),
	) );

	$wpc->add_setting( 'home_slider_show_blog', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'home_slider_show_blog', array(
		'type'    => 'checkbox',
		'section' => 'homepage',
		'label'   => esc_html__( 'Show slider on the blog page.', 'brittany' ),
	) );



	//
	// Typography
	//
	$wpc->add_setting( 'h1_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'h1_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'H1 size', 'brittany' ),
	) );

	$wpc->add_setting( 'h2_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'h2_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'H2 size', 'brittany' ),
	) );

	$wpc->add_setting( 'h3_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'h3_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'H3 size', 'brittany' ),
	) );

	$wpc->add_setting( 'h4_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'h4_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'H4 size', 'brittany' ),
	) );

	$wpc->add_setting( 'h5_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'h5_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'H5 size', 'brittany' ),
	) );

	$wpc->add_setting( 'h6_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'h6_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'H6 size', 'brittany' ),
	) );

	$wpc->add_setting( 'body_text_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'body_text_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'Body text size', 'brittany' ),
	) );

	$wpc->add_setting( 'widgets_title_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'widgets_title_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'Widgets title size', 'brittany' ),
	) );

	$wpc->add_setting( 'widgets_text_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'widgets_text_size', array(
		'type'    => 'number',
		'section' => 'typography',
		'label'   => esc_html__( 'Widgets text size', 'brittany' ),
	) );

	$wpc->add_setting( 'lowercase_content_headings', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'lowercase_content_headings', array(
		'type'    => 'checkbox',
		'section' => 'typography',
		'label'   => esc_html__( 'Lowercase content headings', 'brittany' ),
	) );

	$wpc->add_setting( 'lowercase_widget_titles', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'lowercase_widget_titles', array(
		'type'    => 'checkbox',
		'section' => 'typography',
		'label'   => esc_html__( 'Lowercase widget titles', 'brittany' ),
	) );



	//
	// Global colors
	//
	$wpc->get_control( 'background_color' )->section      = 'global_colors';
	$wpc->get_control( 'background_image' )->section      = 'global_colors';
	$wpc->get_control( 'background_repeat' )->section     = 'global_colors';
	$wpc->get_control( 'background_attachment' )->section = 'global_colors';
	if ( ! is_null( $wpc->get_control( 'background_position_x' ) ) ) {
		$wpc->get_control( 'background_position_x' )->section = 'global_colors';
	} else {
		$wpc->get_control( 'background_position' )->section = 'global_colors';
		$wpc->get_control( 'background_preset' )->section   = 'global_colors';
		$wpc->get_control( 'background_size' )->section     = 'global_colors';
	}

	$wpc->add_setting( 'global_secondary_bg_color', array(
		'transport'         => 'postMessage',
		'default'           => '#FFFFFF',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_secondary_bg_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Secondary Background Color (Box Color)', 'brittany' ),
	) ) );

	$wpc->add_setting( 'global_primary_color', array(
		'transport'         => 'postMessage',
		'default'           => '#e62d4f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_primary_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Primary color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'global_text_color', array(
		'transport'         => 'postMessage',
		'default'           => '#1f1f1f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_text_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Text Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'global_link_color', array(
		'transport'         => 'postMessage',
		'default'           => '#e62d4f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_link_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Content Link Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'global_link_hover_color', array(
		'transport'         => 'postMessage',
		'default'           => '#eb5b75',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_link_hover_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Content Link Hover Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'global_btn_text_color', array(
		'transport'         => 'postMessage',
		'default'           => '#FFFFFF',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_btn_text_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Button Text Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'global_btn_bg_color', array(
		'transport'         => 'postMessage',
		'default'           => '#e62d4f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_btn_bg_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Button Background Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'global_btn_hover_bg_color', array(
		'transport'         => 'postMessage',
		'default'           => '#FFFFFF',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_btn_hover_bg_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Button Hover Background Color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'global_border_color', array(
		'transport'         => 'postMessage',
		'default'           => '#E6E6E6',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'global_border_color', array(
		'section' => 'global_colors',
		'label'   => esc_html__( 'Global Border Color', 'brittany' ),
	) ) );



	//
	// Sidebar colors
	//
	$wpc->add_setting( 'sidebar_bg_color', array(
		'transport'         => 'postMessage',
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'sidebar_bg_color', array(
		'section' => 'sidebar_colors',
		'label'   => esc_html__( 'Background color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'sidebar_text_color', array(
		'transport'         => 'postMessage',
		'default'           => '#1f1f1f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'sidebar_text_color', array(
		'section' => 'sidebar_colors',
		'label'   => esc_html__( 'Text color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'sidebar_link_color', array(
		'transport'         => 'postMessage',
		'default'           => '#e62d4f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'sidebar_link_color', array(
		'section' => 'sidebar_colors',
		'label'   => esc_html__( 'Link color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'sidebar_hover_color', array(
		'transport'         => 'postMessage',
		'default'           => '#eb5b75',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'sidebar_hover_color', array(
		'section' => 'sidebar_colors',
		'label'   => esc_html__( 'Link Hover color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'sidebar_title_color', array(
		'transport'         => 'postMessage',
		'default'           => '#1f1f1f',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'sidebar_title_color', array(
		'section' => 'sidebar_colors',
		'label'   => esc_html__( 'Widget titles color', 'brittany' ),
	) ) );

	$wpc->add_setting( 'sidebar_border_color', array(
		'transport'         => 'postMessage',
		'default'           => '#E6E6E6',
		'sanitize_callback' => 'brittany_sanitize_hex_color',
	) );
	$wpc->add_control( new WP_Customize_Color_Control( $wpc, 'sidebar_border_color', array(
		'section' => 'sidebar_colors',
		'label'   => esc_html__( 'Border color', 'brittany' ),
	) ) );



	//
	// Social
	//
	$wpc->add_setting( 'social_target', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'social_target', array(
		'type'    => 'checkbox',
		'section' => 'social',
		'label'   => esc_html__( 'Open social and sharing links in a new tab.', 'brittany' ),
	) );

	$networks = brittany_get_social_networks();

	foreach ( $networks as $network ) {
		$wpc->add_setting( 'social_' . $network['name'], array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wpc->add_control( 'social_' . $network['name'], array(
			'type'    => 'url',
			'section' => 'social',
			/* translators: %s is a social network's name, e.g. Facebook URL. */
			'label'   => esc_html( sprintf( _x( '%s URL', 'social network url', 'brittany' ), $network['label'] ) ),
		) );
	}

	$wpc->add_setting( 'rss_feed', array(
		'default'           => get_bloginfo( 'rss2_url' ),
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wpc->add_control( 'rss_feed', array(
		'type'    => 'url',
		'section' => 'social',
		'label'   => esc_html__( 'RSS Feed', 'brittany' ),
	) );



	//
	// Single Post
	//
	$wpc->add_setting( 'single_post_layout', array(
		'default'           => 'right-sidebar',
		'sanitize_callback' => 'brittany_sanitize_post_layout_choices',
	) );
	$wpc->add_control( 'single_post_layout', array(
		'type'    => 'select',
		'section' => 'single_post',
		'label'   => esc_html__( 'Single posts default layout', 'brittany' ),
		'choices' => brittany_get_post_layout_choices(),
	) );

	$wpc->add_setting( 'single_categories', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'single_categories', array(
		'type'    => 'checkbox',
		'section' => 'single_post',
		'label'   => esc_html__( 'Show categories.', 'brittany' ),
	) );

	$wpc->add_setting( 'single_date', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'single_date', array(
		'type'    => 'checkbox',
		'section' => 'single_post',
		'label'   => esc_html__( 'Show date.', 'brittany' ),
	) );

	$wpc->add_setting( 'single_comments', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'single_comments', array(
		'type'    => 'checkbox',
		'section' => 'single_post',
		'label'   => esc_html__( 'Show comments.', 'brittany' ),
	) );

	$wpc->add_setting( 'single_signature', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'single_signature', array(
		'type'    => 'checkbox',
		'section' => 'single_post',
		'label'   => esc_html__( 'Show signature.', 'brittany' ),
	) );

	$wpc->add_setting( 'single_authorbox', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'single_authorbox', array(
		'type'    => 'checkbox',
		'section' => 'single_post',
		'label'   => esc_html__( 'Show author box.', 'brittany' ),
	) );

	$wpc->add_setting( 'single_tags', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'single_tags', array(
		'type'    => 'checkbox',
		'section' => 'single_post',
		'label'   => esc_html__( 'Show tags.', 'brittany' ),
	) );

	$wpc->add_setting( 'single_social_sharing', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'single_social_sharing', array(
		'type'    => 'checkbox',
		'section' => 'single_post',
		'label'   => esc_html__( 'Show social sharing buttons.', 'brittany' ),
	) );

	$wpc->add_setting( 'single_related', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'single_related', array(
		'type'    => 'checkbox',
		'section' => 'single_post',
		'label'   => esc_html__( 'Show related articles.', 'brittany' ),
	) );

	$wpc->add_setting( 'single_related_title', array(
		'default'           => esc_html__( 'Related Posts', 'brittany' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wpc->add_control( 'single_related_title', array(
		'type'    => 'text',
		'section' => 'single_post',
		'label'   => esc_html__( 'Related Posts section title', 'brittany' ),
	) );



	//
	// Single Page
	//
	$wpc->add_setting( 'page_signature', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'page_signature', array(
		'type'    => 'checkbox',
		'section' => 'single_page',
		'label'   => esc_html__( 'Show signature.', 'brittany' ),
	) );

	$wpc->add_setting( 'page_social_sharing', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'page_social_sharing', array(
		'type'    => 'checkbox',
		'section' => 'single_page',
		'label'   => esc_html__( 'Show social sharing buttons.', 'brittany' ),
	) );



	//
	// Footer
	//
	$wpc->add_setting( 'footer_text', array(
		'default'           => brittany_get_default_footer_text(),
		'sanitize_callback' => 'brittany_sanitize_footer_text',
	) );
	$wpc->add_control( 'footer_text', array(
		'type'        => 'text',
		'section'     => 'footer',
		'label'       => esc_html__( 'Footer text', 'brittany' ),
		'description' => esc_html__( 'Allowed tags: a (href|class), img (src|class), span (class), i (class), b, em, strong.', 'brittany' ),
	) );

	if ( class_exists( 'null_instagram_widget' ) ) {
		$wpc->add_setting( 'instagram_auto', array(
			'default'           => 1,
			'sanitize_callback' => 'brittany_sanitize_checkbox',
		) );
		$wpc->add_control( 'instagram_auto', array(
			'type'    => 'checkbox',
			'section' => 'footer',
			'label'   => esc_html__( 'WP Instagram: Slideshow.', 'brittany' ),
		) );

		$wpc->add_setting( 'instagram_speed', array(
			'default'           => 300,
			'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
		) );
		$wpc->add_control( 'instagram_speed', array(
			'type'    => 'number',
			'section' => 'footer',
			'label'   => esc_html__( 'WP Instagram: Slideshow Speed.', 'brittany' ),
		) );
	}



	//
	// Other
	//
	$wpc->add_setting( 'google_anaytics_tracking_id', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wpc->add_control( 'google_anaytics_tracking_id', array(
		'type'        => 'text',
		'section'     => 'other',
		'label'       => esc_html__( 'Google Analytics Tracking ID', 'brittany' ),
		/* translators: %s is a url. */
		'description' => wp_kses( sprintf( __( 'Tracking is enabled only for the non-admin portion of your website. If you need fine-grained control of the tracking code, you are strongly adviced to <a href="%s" target="_blank">use a specialty plugin</a> instead.', 'brittany' ), 'https://wordpress.org/plugins/search.php?q=analytics' ), brittany_get_allowed_tags( 'guide' ) ),
	) );



	//
	// title_tagline Section
	//
	$wpc->add_setting( 'limit_logo_size', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'limit_logo_size', array(
		'type'        => 'checkbox',
		'section'     => 'title_tagline',
		'priority'    => 8,
		'label'       => esc_html__( 'Limit logo size (for Retina display)', 'brittany' ),
		'description' => esc_html__( 'This option will limit the logo size to half its width. You will need to upload your logo in 2x the dimension you want to display it in.', 'brittany' ),
	) );

	$wpc->add_setting( 'logo_site_title', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'logo_site_title', array(
		'type'    => 'checkbox',
		'section' => 'title_tagline',
		'label'   => esc_html__( 'Show site title below the logo.', 'brittany' ),
	) );

	$wpc->add_setting( 'logo_tagline', array(
		'default'           => 1,
		'sanitize_callback' => 'brittany_sanitize_checkbox',
	) );
	$wpc->add_control( 'logo_tagline', array(
		'type'        => 'checkbox',
		'section'     => 'title_tagline',
		'label'       => esc_html__( 'Show the tagline below the logo.', 'brittany' ),
		'description' => wp_kses( __( 'The tagline is always hidden when the <strong>Inline logo</strong> option is enabled.', 'brittany' ), brittany_get_allowed_tags() ),
	) );

	$wpc->add_setting( 'logo_padding_top', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'logo_padding_top', array(
		'type'    => 'number',
		'section' => 'title_tagline',
		'label'   => esc_html__( 'Logo top padding', 'brittany' ),
	) );

	$wpc->add_setting( 'logo_padding_bottom', array(
		'default'           => '',
		'sanitize_callback' => 'brittany_sanitize_intval_or_empty',
	) );
	$wpc->add_control( 'logo_padding_bottom', array(
		'type'    => 'number',
		'section' => 'title_tagline',
		'label'   => esc_html__( 'Logo bottom padding', 'brittany' ),
	) );

}

add_action( 'customize_register', 'brittany_customize_register_custom_controls', 9 );
/**
 * Registers custom Customizer controls.
 *
 * @param WP_Customize_Manager $wpc Reference to the customizer's manager object.
 */
function brittany_customize_register_custom_controls( $wpc ) {
	require_once get_theme_file_path( '/inc/customizer-controls/static-text.php' );
	require_once get_theme_file_path( '/inc/customizer-controls/flexslider.php' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function brittany_base_customize_preview_js() {
	wp_enqueue_script( 'brittany-customizer-preview', get_theme_file_uri( '/js/customizer-preview.js' ), array( 'customize-preview' ), brittany_asset_version(), true );
}
add_action( 'customize_preview_init', 'brittany_base_customize_preview_js' );
