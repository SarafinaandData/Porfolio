<?php
	add_action( 'admin_init', 'brittany_cpt_post_add_metaboxes' );
	add_action( 'save_post', 'brittany_cpt_post_update_meta' );

	function brittany_cpt_post_add_metaboxes() {
		add_meta_box( 'brittany-post-layout', esc_html__( 'Layout', 'brittany' ), 'brittany_add_post_layout_meta_box', 'post', 'normal', 'high' );
	}

	function brittany_cpt_post_update_meta( $post_id ) {

		// Nonce verification is being done inside brittany_can_save_meta()
		// phpcs:disable WordPress.Security.NonceVerification
		if ( ! brittany_can_save_meta( 'post' ) ) {
			return;
		}

		update_post_meta( $post_id, 'brittany_layout', brittany_sanitize_post_layout_choices( $_POST['brittany_layout'] ) );
		update_post_meta( $post_id, 'brittany_hide_featured', brittany_sanitize_checkbox_ref( $_POST['brittany_hide_featured'] ) );

		// phpcs:enable
	}

	function brittany_add_post_layout_meta_box( $object, $box ) {
		brittany_prepare_metabox( 'post' );

		?><div class="ci-cf-wrap"><?php
			brittany_metabox_open_tab( '' );
				brittany_metabox_checkbox( 'brittany_hide_featured', 1, esc_html__( "Don't show this article's featured image.", 'brittany' ) );

				brittany_metabox_guide( wp_kses( __( 'You may enforce a specific layout for this individual post, by selecting the one desired below. Choose <em>Inherit</em> if you want the post to follow the <strong>Blog page layout</strong> option selected through <em>Appearance > Customize > Layout Options</em>.', 'brittany' ), array( 'em' => array() ) ) );

				$choices = array_merge( array(
					'' => esc_html_x( 'Inherit', 'post layout', 'brittany' ),
				), brittany_get_post_layout_choices() );
				brittany_metabox_dropdown( 'brittany_layout', $choices, esc_html__( 'Post layout:', 'brittany' ) );
			brittany_metabox_close_tab();
		?></div><?php
	}
