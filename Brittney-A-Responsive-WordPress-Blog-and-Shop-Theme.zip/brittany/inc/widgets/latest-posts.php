<?php
if ( ! class_exists( 'CI_Widget_Latest_Posts' ) ) :
	class CI_Widget_Latest_Posts extends WP_Widget {

		protected $defaults = array(
			'title'    => '',
			'category' => '',
			'exclude'  => '',
			'random'   => '',
			'count'    => 3,
			'columns'  => 2,
			'layout'   => '',
		);

		public function __construct() {
			$widget_ops  = array( 'description' => esc_html__( 'Displays a number of the latest (or random) posts from a specific category.', 'brittany' ) );
			$control_ops = array();
			parent::__construct( 'ci-latest-posts', esc_html__( 'Theme - Latest Posts', 'brittany' ), $widget_ops, $control_ops );
		}

		public function widget( $args, $instance ) {
			$instance = wp_parse_args( (array) $instance, $this->defaults );

			$id = isset( $args['id'] ) ? $args['id'] : '';

			$title    = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
			$category = $instance['category'];
			$exclude  = $instance['exclude'];
			$random   = (int) $instance['random'];
			$count    = (int) $instance['count'];
			$columns  = (int) $instance['columns'];
			$layout   = $instance['layout'];

			if ( 0 === $count ) {
				return;
			}

			$qargs = array(
				'orderby'             => 'date',
				'order'               => 'DESC',
				'posts_per_page'      => $count,
				'ignore_sticky_posts' => true,
			);

			if ( 1 === $random ) {
				$qargs['orderby'] = 'rand';
				unset( $qargs['order'] );
			}

			if ( ! empty( $category ) && $category > 0 ) {
				$qargs['cat'] = intval( $category );
			}

			if ( ! empty( $exclude ) ) {
				$qargs['category__not_in'] = $exclude;
			}

			$q = new WP_Query( $qargs );


			if ( $q->have_posts() ) {

				echo $args['before_widget'];

				if ( ! empty( $title ) ) {
					echo $args['before_title'] . $title . $args['after_title'];
				}

				if ( in_array( $id, brittany_get_fullwidth_sidebars(), true ) ) {
					?><div class="row item-row"><?php
				}

				$i = 0;
				while ( $q->have_posts() ) {
					$q->the_post();
					$i++;

					if ( in_array( $id, brittany_get_fullwidth_sidebars(), true ) ) {
						$columns_classes = brittany_get_columns_classes( $columns );
						$post_layout     = $layout;

						if ( 3 === $columns && in_array( $id, array( 'homepage-fullscreen-slider' ), true ) ) {
							$columns_classes = 'col-md-4 col-sm-4 col-xs-12';
						}

						//
						// The rest of the code inside this block, is copied from index.php
						//

						if ( $columns > 1 ) {
							echo sprintf( '<div class="%s">', esc_attr( $columns_classes ) );
						}

						if ( in_array( $post_layout, array( 'horizontal-alt', 'horizontal-fixed-alt' ), true ) ) {
							// Handle layouts that end in '-alt'
							// These do not really map to a single item-*.php file so they need special handling here.
							$layout_cleaned = preg_replace( '/-alt$/', '', $post_layout );

							if ( $i % 2 ) {
								get_template_part( "item-{$layout_cleaned}-left", get_post_type() );
							} else {
								get_template_part( "item-{$layout_cleaned}-right", get_post_type() );
							}
						} else {
							// Unfortunately we can't have the versatility of get_template_part() with two separate parameters
							// i.e. $post_layout and get_post_type, so we need to handle an empty $post_layout manually.
							// Also note that in case of a missing item-* template it will not fall back to item.php
							// Instead, only fallback for custom post types is provided, i.e. item-media-product will fall back to item-media.
							if ( ! empty( $post_layout ) ) {
								get_template_part( "item-{$post_layout}", get_post_type() );
							} else {
								get_template_part( 'item', get_post_type() );
							}
						}

						if ( $columns > 1 ) {
							echo '</div>';
						}
					} else {
						get_template_part( 'item-media', get_post_type() );
					}
				}
				wp_reset_postdata();

				if ( in_array( $id, brittany_get_fullwidth_sidebars(), true ) ) {
					?></div><?php
				}

				echo $args['after_widget'];
			}

		}

		public function update( $new_instance, $old_instance ) {
			$instance = $old_instance;

			$instance['title']    = sanitize_text_field( $new_instance['title'] );
			$instance['category'] = brittany_sanitize_intval_or_empty( $new_instance['category'] );
			$instance['random']   = brittany_sanitize_checkbox_ref( $new_instance['random'] );
			$instance['count']    = intval( $new_instance['count'] ) > 0 ? intval( $new_instance['count'] ) : 1;
			$instance['columns']  = in_array( (int) $new_instance['columns'], range( 1, 4 ), true ) ? intval( $new_instance['columns'] ) : $this->defaults['columns'];
			$instance['layout']   = brittany_sanitize_blog_post_layout_choices( $new_instance['layout'] );

			if ( ! empty( $new_instance['exclude'] ) && is_array( $new_instance['exclude'] ) ) {
				$exclude = $new_instance['exclude'];
				$exclude = array_map( 'intval', $exclude );
				$exclude = array_filter( $exclude );

				$instance['exclude'] = $exclude;
			} else {
				$instance['exclude'] = array();
			}

			return $instance;
		}

		public function form( $instance ) {
			$instance = wp_parse_args( (array) $instance, $this->defaults );

			$title    = $instance['title'];
			$category = $instance['category'];
			$exclude  = $instance['exclude'];
			$random   = $instance['random'];
			$count    = $instance['count'];
			$columns  = $instance['columns'];
			$layout   = $instance['layout'];

			?>
			<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'brittany' ); ?></label><input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" class="widefat"/></p>

			<p><label for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>"><?php esc_html_e( 'Category to display the latest posts from (optional):', 'brittany' ); ?></label>
			<?php wp_dropdown_categories( array(
				'taxonomy'          => 'category',
				'show_option_all'   => '',
				'show_option_none'  => ' ',
				'option_none_value' => '',
				'show_count'        => 1,
				'echo'              => 1,
				'selected'          => $category,
				'hierarchical'      => 1,
				'name'              => $this->get_field_name( 'category' ),
				'id'                => $this->get_field_id( 'category' ),
				'class'             => 'postform widefat',
			) ); ?>

			<p><label for="<?php echo esc_attr( $this->get_field_id( 'exclude' ) ); ?>"><?php esc_html_e( 'Categories to exclude latest posts from (optional):', 'brittany' ); ?></label>
			<ul class="exclude-category">
			<?php
				$terms_dd = wp_terms_checklist( 0, array(
					'taxonomy'      => 'category',
					'selected_cats' => $exclude,
					'checked_ontop' => false,
					'echo'          => false,
				) );
				$terms_dd = str_replace( 'post_category[]', $this->get_field_name( 'exclude[]' ), $terms_dd );
				echo $terms_dd;
			?>
			</ul>

			<p><label for="<?php echo esc_attr( $this->get_field_id( 'random' ) ); ?>"><input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'random' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'random' ) ); ?>" value="1" <?php checked( $random, 1 ); ?> /><?php esc_html_e( 'Show random posts.', 'brittany' ); ?></label></p>

			<p><label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'brittany' ); ?></label><input id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="number" min="1" step="1" value="<?php echo esc_attr( $count ); ?>" class="widefat"/></p>

			<p><?php echo wp_kses( __( '<em>The options below apply only to the <strong>wide</strong> widget areas, e.g. on the Homepage.</em>', 'brittany' ), brittany_get_allowed_tags( 'guide' ) ); ?></p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'columns' ) ); ?>"><?php esc_html_e( 'Output Columns:', 'brittany' ); ?></label>
				<select id="<?php echo esc_attr( $this->get_field_id( 'columns' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'columns' ) ); ?>" class="widefat">
					<?php for ( $i = 1; $i <= 4; $i ++ ) {
						echo sprintf( '<option value="%s" %s>%s</option>',
							esc_attr( $i ),
							selected( $columns, $i, false ),
							/* translators: %d is a number of columns.  */
							esc_html( sprintf( _n( '%d Column', '%d Columns', $i, 'brittany' ), $i ) )
						);
					} ?>
				</select>
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"><?php esc_html_e( 'Item appearance:', 'brittany' ); ?></label>
				<select id="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>" class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'layout' ) ); ?>">
					<?php $choices = brittany_get_blog_post_layout_choices(); ?>
					<?php foreach ( $choices as $value => $description ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $value, $layout ); ?>><?php echo wp_kses( $description, 'strip' ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			<?php

		}


	}

	register_widget( 'CI_Widget_Latest_Posts' );

endif;
