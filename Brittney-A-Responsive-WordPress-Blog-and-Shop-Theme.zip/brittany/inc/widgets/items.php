<?php
if ( ! class_exists( 'CI_Widget_Items' ) ) :
	class CI_Widget_Items extends WP_Widget {

		public $ajax_action = 'brittany_items_widget_post_type_ajax_get_posts';

		protected $defaults = array(
			'title'      => '',
			'post_types' => array(),
			'postids'    => array(),
			'columns'    => 2,
			'layout'     => '',
		);

		public function __construct() {
			$widget_ops  = array( 'description' => esc_html__( 'Displays a hand-picked selection of posts from a selected post type.', 'brittany' ) );
			$control_ops = array();

			parent::__construct( 'ci-items', $name = esc_html__( 'Theme - Items', 'brittany' ), $widget_ops, $control_ops );

			if ( is_admin() === true ) {
				add_action( 'wp_ajax_' . $this->ajax_action, 'CI_Widget_Items::_ajax_get_posts' );
			}
		}

		public function widget( $args, $instance ) {
			$instance = wp_parse_args( (array) $instance, $this->defaults );

			$id = isset( $args['id'] ) ? $args['id'] : '';

			$title   = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
			$types   = $instance['post_types'];
			$ids     = $instance['postids'];
			$count   = max( count( $types ), count( $ids ) );
			$columns = (int) $instance['columns'];
			$layout  = $instance['layout'];

			if ( empty( $types ) || empty( $ids ) ) {
				return;
			}


			echo $args['before_widget'];

			if ( ! empty( $title ) ) {
				echo $args['before_title'] . $title . $args['after_title'];
			}

			if ( in_array( $id, brittany_get_fullwidth_sidebars(), true ) ) {
				?><div class="row item-row"><?php
			}

			$i = 0;
			for ( $current = 0; $current < $count; $current++ ) {
				$pid       = $ids[ $current ];
				$post_type = $types[ $current ];

				$q = new WP_Query( array(
					'post_type'           => $post_type,
					'p'                   => $pid,
					'ignore_sticky_posts' => true,
				) );

				while ( $q->have_posts() ) {
					$q->the_post();
					$i++;

					if ( in_array( $id, brittany_get_fullwidth_sidebars(), true ) ) {
						$columns_classes = brittany_get_columns_classes( $columns );
						$post_layout     = $layout;

						if ( 3 === $columns && in_array( $id, array( 'homepage-fullscreen-slider' ), true ) ) {
							$columns_classes = 'col-md-4 col-sm-4 col-xs-12';
						}

						//
						// The rest of the code inside this block, is copied from index.html
						//

						if ( $columns > 1 ) {
							echo sprintf( '<div class="%s">', esc_attr( $columns_classes ) );
						}

						if ( in_array( $post_layout, array( 'horizontal-alt', 'horizontal-fixed-alt' ), true ) ) {
							// Handle layouts that end in '-alt'
							// These do not really map to a single item-*.php file so they need special handling here.
							$layout_cleaned = preg_replace( '/-alt$/', '', $post_layout );

							if ( $i % 2 ) {
								get_template_part( "item-{$layout_cleaned}-left", get_post_type() );
							} else {
								get_template_part( "item-{$layout_cleaned}-right", get_post_type() );
							}
						} else {
							// Unfortunately we can't have the versatility of get_template_part() with two separate parameters
							// i.e. $post_layout and get_post_type, so we need to handle an empty $post_layout manually.
							// Also note that in case of a missing item-* template it will not fall back to item.php
							// Instead, only fallback for custom post types is provided, i.e. item-media-product will fall back to item-media.
							if ( ! empty( $post_layout ) ) {
								get_template_part( "item-{$post_layout}", get_post_type() );
							} else {
								get_template_part( 'item', get_post_type() );
							}
						}

						if ( $columns > 1 ) {
							echo '</div>';
						}
					} else {
						get_template_part( 'item-media', get_post_type() );
					}
				}
				wp_reset_postdata();
			}

			if ( in_array( $id, brittany_get_fullwidth_sidebars(), true ) ) {
				?></div><?php
			}

			echo $args['after_widget'];

		}

		public function update( $new_instance, $old_instance ) {
			$instance = $old_instance;

			$instance['title'] = sanitize_text_field( $new_instance['title'] );

			// Sanitize repeating fields. Remove empty entries.
			$instance['post_types'] = array();
			$instance['postids']    = array();

			$types = $new_instance['post_types'];
			$ids   = $new_instance['postids'];
			$count = max( count( $types ), count( $ids ) );

			for ( $i = 0; $i < $count; $i ++ ) {
				if ( ! empty( $types[ $i ] ) && ! empty( $ids[ $i ] ) ) {
					$instance['post_types'][] = sanitize_key( $types[ $i ] );
					$instance['postids'][]    = absint( $ids[ $i ] );
				}
			}

			$instance['columns'] = in_array( (int) $new_instance['columns'], range( 1, 4 ), true ) ? intval( $new_instance['columns'] ) : $this->defaults['columns'];
			$instance['layout']  = brittany_sanitize_blog_post_layout_choices( $new_instance['layout'] );

			return $instance;
		}

		public function form( $instance ) {
			$instance = wp_parse_args( (array) $instance, $this->defaults );

			$title      = $instance['title'];
			$post_types = $instance['post_types'];
			$postids    = $instance['postids'];
			$columns    = $instance['columns'];
			$layout     = $instance['layout'];

			?><p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'brittany' ); ?></label><input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" class="widefat"/></p><?php

			$post_types_available = get_post_types( array( 'public' => true ), 'objects' );
			unset( $post_types_available['attachment'], $post_types_available['brittany_event'] );

			$posttypes_name = $this->get_field_name( 'post_types' ) . '[]';
			$ids_name       = $this->get_field_name( 'postids' ) . '[]';

			?>
			<p><?php esc_html_e( 'Add as many items as you want by pressing the "Add Item" button. Remove any item by selecting "Remove me".', 'brittany' ); ?></p>
			<fieldset class="ci-repeating-fields ci-items">
				<div class="inner">
					<?php
						if ( ! empty( $postids ) && ! empty( $post_types ) ) {
							$count = max( count( $postids ), count( $post_types ) );
							for ( $i = 0; $i < $count; $i++ ) {
								?>
								<div class="post-field" data-ajaxaction="<?php echo esc_attr( $this->ajax_action ); ?>">
									<label class="post-field-type"><?php esc_html_e( 'Post type:', 'brittany' ); ?>
										<select name="<?php echo esc_attr( $posttypes_name ); ?>" class="widefat posttype_dropdown">
											<?php
												foreach ( $post_types_available as $key => $pt ) {
													?><option value="<?php echo esc_attr( $key ); ?>" <?php selected( $key, $post_types[ $i ] ); ?>><?php echo esc_html( $pt->labels->name ); ?></option><?php
												}
											?>
										</select>
									</label>
									<label class="post-field-item"><?php esc_html_e( 'Item:', 'brittany' ); ?>
										<?php
											brittany_dropdown_posts( array(
												'post_type'            => $post_types[ $i ],
												'selected'             => $postids[ $i ],
												'class'                => 'widefat posts_dropdown',
												'show_option_none'     => '&nbsp;',
												'select_even_if_empty' => true,
											), $ids_name );
										?>
									</label>
									<p class="ci-repeating-remove-action"><a href="#" class="button ci-repeating-remove-field"><i class="dashicons dashicons-dismiss"></i><?php esc_html_e( 'Remove me', 'brittany' ); ?></a></p>
								</div>
								<?php
							}
						}
					?>
					<?php
					//
					// Add an empty and hidden set for jQuery
					//
					?>
					<div class="post-field field-prototype" style="display: none;" data-ajaxaction="<?php echo esc_attr( $this->ajax_action ); ?>">
						<label class="post-field-type"><?php esc_html_e( 'Post type:', 'brittany' ); ?>
							<select name="<?php echo esc_attr( $posttypes_name ); ?>" class="widefat posttype_dropdown">
								<?php
									foreach ( $post_types_available as $key => $pt ) {
										?><option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $pt->labels->name ); ?></option><?php
									}
								?>
							</select>
						</label>
						<label class="post-field-item"><?php esc_html_e( 'Item:', 'brittany' ); ?>
							<?php
								brittany_dropdown_posts( array(
									'post_type'            => 'post',
									'class'                => 'widefat posts_dropdown',
									'show_option_none'     => '&nbsp;',
									'select_even_if_empty' => true,
								), $ids_name );
							?>
						</label>
						<p class="ci-repeating-remove-action"><a href="#" class="button ci-repeating-remove-field"><i class="dashicons dashicons-dismiss"></i><?php esc_html_e( 'Remove me', 'brittany' ); ?></a></p>
					</div>
				</div>
				<a href="#" class="ci-repeating-add-field button"><i class="dashicons dashicons-plus-alt"></i><?php esc_html_e( 'Add Item', 'brittany' ); ?></a>
			</fieldset>

			<p><?php echo wp_kses( __( '<em>The options below apply only to the <strong>wide</strong> widget areas, e.g. on the Homepage.</em>', 'brittany' ), brittany_get_allowed_tags( 'guide' ) ); ?></p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'columns' ) ); ?>"><?php esc_html_e( 'Output Columns:', 'brittany' ); ?></label>
				<select id="<?php echo esc_attr( $this->get_field_id( 'columns' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'columns' ) ); ?>" class="widefat">
					<?php for ( $i = 1; $i <= 4; $i ++ ) {
						echo sprintf( '<option value="%s" %s>%s</option>',
							esc_attr( $i ),
							selected( $columns, $i, false ),
							/* translators: %d is a number of columns.  */
							esc_html( sprintf( _n( '%d Column', '%d Columns', $i, 'brittany' ), $i ) )
						);
					} ?>
				</select>
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"><?php esc_html_e( 'Item appearance:', 'brittany' ); ?></label>
				<select id="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>" class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'layout' ) ); ?>">
					<?php $choices = brittany_get_blog_post_layout_choices(); ?>
					<?php foreach ( $choices as $value => $description ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $value, $layout ); ?>><?php echo wp_kses( $description, 'strip' ); ?></option>
					<?php endforeach; ?>
				</select>
			</p>
			<?php
		}

		public static function _ajax_get_posts() {
			$post_type_name = sanitize_key( $_POST['post_type_name'] );
			$name_field     = esc_attr( $_POST['name_field'] );

			brittany_dropdown_posts( array(
				'post_type'            => $post_type_name,
				'class'                => 'widefat posts_dropdown',
				'show_option_none'     => '&nbsp;',
				'select_even_if_empty' => true,
			), $name_field );

			die;
		}

	}

	register_widget( 'CI_Widget_Items' );

endif;
