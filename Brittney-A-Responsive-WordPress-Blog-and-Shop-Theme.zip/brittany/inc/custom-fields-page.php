<?php
	add_action( 'admin_init', 'brittany_cpt_page_add_metaboxes' );
	add_action( 'save_post', 'brittany_cpt_page_update_meta' );

	function brittany_cpt_page_add_metaboxes() {
		add_meta_box( 'brittany-page-layout', esc_html__( 'Layout', 'brittany' ), 'brittany_add_page_layout_meta_box', 'page', 'normal', 'high' );
	}

	function brittany_cpt_page_update_meta( $post_id ) {

		// Nonce verification is being done inside brittany_can_save_meta()
		// phpcs:disable WordPress.Security.NonceVerification
		if ( ! brittany_can_save_meta( 'page' ) ) {
			return;
		}

		update_post_meta( $post_id, 'brittany_hide_featured', brittany_sanitize_checkbox_ref( $_POST['brittany_hide_featured'] ) );

		// phpcs:enable
	}

	function brittany_add_page_layout_meta_box( $object, $box ) {
		brittany_prepare_metabox( 'page' );

		?><div class="ci-cf-wrap"><?php
			brittany_metabox_open_tab( '' );
				brittany_metabox_checkbox( 'brittany_hide_featured', 1, esc_html__( "Don't show this page's featured image.", 'brittany' ) );
			brittany_metabox_close_tab();
		?></div><?php
	}
