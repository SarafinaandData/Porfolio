<?php
	$author_id       = get_the_author_meta( 'ID' );
	$signoff_text    = get_user_option( 'user_greeting_text', $author_id );
	$signature_text  = get_user_option( 'user_signature_text', $author_id );
	$signature_image = get_user_option( 'user_signature_image', $author_id );
?>
<?php if ( ! empty( $signoff_text ) || ! empty( $signature_text ) || ! empty( $signature_image ) ) : ?>
	<div class="entry-signature">
		<?php if ( ! empty( $signoff_text ) ) : ?>
			<p class="entry-signature-greet"><?php echo esc_html( $signoff_text ); ?></p>
		<?php endif; ?>

		<?php if ( ! empty( $signature_image ) ) : ?>
			<p class="entry-sig-img"><?php echo wp_get_attachment_image( $signature_image, 'full' ); ?></p>
		<?php elseif ( ! empty( $signature_text ) ) : ?>
			<p class="entry-sig-img"><?php echo esc_html( $signature_text ); ?></p>
		<?php endif; ?>
	</div>
<?php endif;
