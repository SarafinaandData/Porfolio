<?php
	$q    = false;
	$args = array(
		'post_type'           => 'post',
		'ignore_sticky_posts' => true,
	);

	if ( get_theme_mod( 'home_slider_postids' ) ) {
		$args = array(
			'post_type'           => 'post',
			'post__in'            => explode( ',', get_theme_mod( 'home_slider_postids' ) ),
			'posts_per_page'      => get_theme_mod( 'home_slider_limit', 5 ),
			'orderby'             => 'post__in',
			'ignore_sticky_posts' => true,
		);
	} elseif ( get_theme_mod( 'home_slider_term' ) ) {
		$args = array_merge( $args, array(
			'post_type'           => 'post',
			'tax_query'           => array(
				array(
					'taxonomy' => 'category',
					'terms'    => get_theme_mod( 'home_slider_term' ),
				),
			),
			'posts_per_page'      => get_theme_mod( 'home_slider_limit', 5 ),
			'ignore_sticky_posts' => true,
		) );
	}

	if ( false !== $args ) {
		$q = new WP_Query( $args );
	}

	$attributes = sprintf( 'data-slideshow="%s" data-slideshowspeed="%s" data-animationspeed="%s"',
		esc_attr( get_theme_mod( 'home_slider_slideshow', 1 ) ),
		esc_attr( get_theme_mod( 'home_slider_slideshowSpeed', 3000 ) ),
		esc_attr( get_theme_mod( 'home_slider_animationSpeed', 600 ) )
	);
?>
<?php if ( false !== $args && false !== $q && $q->have_posts() ) : ?>
	<div class="entry-slider ci-main-slider ci-slider loading" <?php echo $attributes; ?>>
		<ul class="slides">
			<?php while ( $q->have_posts() ) : $q->the_post(); ?>
				<li>
					<?php get_template_part( 'item-xl' ); ?>
				</li>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
		</ul>
	</div>
<?php endif;
