<?php
/*
 * Template Name: Widgetized Homepage with Fullscreen Slider
 */
?>

<?php get_header(); ?>

<?php
	$q    = false;
	$args = array(
		'post_type' => 'post',
	);

	if ( get_theme_mod( 'home_slider_postids' ) ) {
		$args = array(
			'post_type'      => 'post',
			'post__in'       => explode( ',', get_theme_mod( 'home_slider_postids' ) ),
			'posts_per_page' => get_theme_mod( 'home_slider_limit', 5 ),
			'orderby'        => 'post__in',
		);
	} elseif ( get_theme_mod( 'home_slider_term' ) ) {
		$args = array_merge( $args, array(
			'post_type'      => 'post',
			'tax_query'      => array(
				array(
					'taxonomy' => 'category',
					'terms'    => get_theme_mod( 'home_slider_term' ),
				),
			),
			'posts_per_page' => get_theme_mod( 'home_slider_limit', 5 ),
		) );
	}

	if ( false !== $args ) {
		$q = new WP_Query( $args );
	}

	$attributes = sprintf( 'data-slideshow="%s" data-slideshowspeed="%s" data-animationspeed="%s"',
		esc_attr( get_theme_mod( 'home_slider_slideshow', 1 ) ),
		esc_attr( get_theme_mod( 'home_slider_slideshowSpeed', 3000 ) ),
		esc_attr( get_theme_mod( 'home_slider_animationSpeed', 600 ) )
	);
?>

<?php if ( false !== $args && false !== $q && $q->have_posts() ) : ?>
	<div class="home-slider ci-main-slider ci-slider loading" <?php echo $attributes; ?>>

		<?php if ( ! get_theme_mod( 'header_logo' ) ) : ?>
			<div class="logo-wrap">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<div class="site-logo">
								<?php if ( function_exists( 'the_custom_logo' ) ) {
									the_custom_logo();
								} ?>

								<?php if ( get_theme_mod( 'logo_site_title', 1 ) ) : ?>
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo-textual">
										<?php bloginfo( 'name' ); ?>
									</a>
								<?php endif; ?>
							</div>

							<?php if ( get_bloginfo( 'description' ) && get_theme_mod( 'logo_tagline', 1 ) ) : ?>
								<p class="site-tagline"><?php bloginfo( 'description' ); ?></p>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<ul class="slides">

			<?php while ( $q->have_posts() ) : $q->the_post(); ?>
				<li style="background-image: url(<?php echo esc_url( wp_get_attachment_image_url( get_post_thumbnail_id(), 'brittany_slider_full' ) ); ?>);">
					<div class="slide-content">
						<div class="container">
							<div class="row">
								<div class="col-xs-12">
									<div class="entry-item-content-wrap">
										<div class="entry-item-footer">
											<div class="entry-item-title">
												<p>
													<a href="<?php the_permalink(); ?>">
														<?php the_title(); ?>
													</a>
												</p>
											</div>

											<div class="entry-slide-control">
												<a href="#" class="entry-slide-prev"><i class="fas fa-angle-left"></i><span class="screen-reader-text"><?php esc_html( 'Previous slide', 'brittany' ); ?></span></a>
												<a href="#" class="entry-slide-next"><i class="fas fa-angle-right"></i><span class="screen-reader-text"><?php esc_html( 'Next slide', 'brittany' ); ?></span></a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</li>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>

		</ul>

		<?php if ( is_active_sidebar( 'homepage-fullscreen-slider' ) ) : ?>
			<div class="slider-widgets">
				<div class="container">
					<?php dynamic_sidebar( 'homepage-fullscreen-slider' ); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>
<?php endif; ?>

<?php get_footer();
