<?php
/*
 * Template Name: Widgetized Homepage with Fullwidth Slider
 */
?>

<?php get_header(); ?>

<?php if ( get_theme_mod( 'home_slider_show_home', 1 ) ) {
	get_template_part( 'part-slider-fullwidth' );
} ?>

<main class="main">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section-widgets">
					<?php dynamic_sidebar( 'homepage' ); ?>
				</div>
			</div>
		</div>
	</div>
</main>

<?php get_footer();
