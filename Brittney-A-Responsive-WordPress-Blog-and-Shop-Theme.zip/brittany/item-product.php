<article class="entry-item entry-item-vertical">
	<?php woocommerce_template_loop_product_thumbnail(); ?>

	<div class="entry-item-content-wrap">
		<div class="entry-item-content">
			<?php woocommerce_template_loop_price(); ?>
			<?php woocommerce_template_loop_product_title(); ?>
		</div>

		<div class="entry-item-footer">
			<div class="entry-item-categories">
				<?php echo get_the_term_list( get_the_ID(), 'product_cat', '', ', ', '' ); ?>
			</div>

			<?php get_template_part( 'part-social-sharing' ); ?>
		</div>
	</div>
</article>
