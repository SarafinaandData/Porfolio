<article id="entry-<?php the_ID(); ?>" <?php post_class( 'entry-item entry-item-vertical entry-item-plain' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<figure class="entry-item-thumb">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'brittany_plain' ); ?>
			</a>
		</figure>
	<?php endif; ?>

	<div class="entry-item-content-wrap">
		<div class="entry-item-content">
			<h2 class="entry-item-title">
				<a href="<?php the_permalink(); ?>">
					<?php the_title(); ?>
				</a>
			</h2>
		</div>
	</div>
</article>
