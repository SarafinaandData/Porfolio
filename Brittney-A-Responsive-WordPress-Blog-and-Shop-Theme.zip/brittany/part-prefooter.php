<?php if ( is_active_sidebar( 'prefooter-widgets' ) ) : ?>
	<div class="col-xs-12">
		<div class="section-widgets">
			<?php dynamic_sidebar( 'prefooter-widgets' ); ?>
		</div>
	</div>
<?php endif;
