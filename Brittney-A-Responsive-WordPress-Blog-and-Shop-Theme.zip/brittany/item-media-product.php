<article class="entry-item-media">
	<figure class="entry-item-thumb">
		<a href="<?php the_permalink(); ?>">
			<?php echo woocommerce_get_product_thumbnail( 'brittany_square' ); ?>
		</a>
	</figure>

	<div class="entry-item-media-content">
		<?php woocommerce_template_loop_price(); ?>
		<?php woocommerce_template_loop_product_title(); ?>
	</div>
</article>
