<?php get_header(); ?>

<?php
	$blog_layout     = get_theme_mod( 'blog_layout', 'right-sidebar' );
	$content_classes = 'col-md-8';
	$sidebar_classes = 'col-md-4';
	$has_sidebar     = true;

	switch ( $blog_layout ) {
		case 'fullwidth':
			$content_classes = 'col-xs-12';
			$sidebar_classes = '';
			$has_sidebar     = false;
			break;
		case 'fullwidth-narrow':
			$content_classes = 'col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12';
			$sidebar_classes = '';
			$has_sidebar     = false;
			break;
		case 'left-sidebar':
			$content_classes = 'col-md-8 col-md-push-4';
			$sidebar_classes = 'col-md-4 col-md-pull-8';
			$has_sidebar     = true;
			break;
		case 'right-sidebar':
		default:
			$content_classes = 'col-md-8';
			$sidebar_classes = 'col-md-4';
			$has_sidebar     = true;
	}
?>

<main class="main">
	<div class="container">
		<div class="row">

			<?php if ( ( is_home() || is_front_page() ) && get_theme_mod( 'home_slider_show_blog', 1 ) ) : ?>
				<div class="col-xs-12">
					<section class="widget">
						<?php get_template_part( 'part-slider' ); ?>
					</section>
				</div>
			<?php endif; ?>

			<div class="<?php echo esc_attr( $content_classes ); ?>">
				<?php if ( is_archive() ) : ?>
					<h2 class="section-title"><?php the_archive_title(); ?></h2>
				<?php endif; ?>

				<?php
					$post_layout     = get_theme_mod( 'blog_items_layout', '' );
					$columns         = get_theme_mod( 'blog_columns', 1 );
					$columns_classes = brittany_get_columns_classes( $columns );
				?>

				<?php if ( $columns > 1 ) : ?>
					<div class="row row-items">
				<?php endif; ?>

				<?php
					$i = 0;
					while ( have_posts() ) {
						the_post();
						$i++;

						if ( $columns > 1 ) {
							echo sprintf( '<div class="%s">', esc_attr( $columns_classes ) );
						}

						if ( in_array( $post_layout, array( 'horizontal-alt', 'horizontal-fixed-alt' ), true ) ) {
							// Handle layouts that end in '-alt'
							// These do not really map to a single item-*.php file so they need special handling here.
							$layout_cleaned = preg_replace( '/-alt$/', '', $post_layout );

							if ( $i % 2 ) {
								get_template_part( "item-{$layout_cleaned}-left", get_post_type() );
							} else {
								get_template_part( "item-{$layout_cleaned}-right", get_post_type() );
							}
						} else {
							// Unfortunately we can't have the versatility of get_template_part() with two separate parameters
							// i.e. $post_layout and get_post_type, so we need to handle an empty $post_layout manually.
							// Also note that in case of a missing item-* template it will not fall back to item.php
							// Instead, only fallback for custom post types is provided, i.e. item-media-product will fall back to item-media.
							if ( ! empty( $post_layout ) ) {
								get_template_part( "item-{$post_layout}", get_post_type() );
							} else {
								get_template_part( 'item', get_post_type() );
							}
						}

						if ( $columns > 1 ) {
							echo '</div>';
						}
					}
				?>

				<?php if ( $columns > 1 ) : ?>
					</div>
				<?php endif; ?>

				<?php brittany_pagination(); ?>
			</div>

			<?php if ( $has_sidebar ) : ?>
				<div class="<?php echo esc_attr( $sidebar_classes ); ?>">
					<?php get_sidebar(); ?>
				</div>
			<?php endif; ?>

			<?php get_template_part( 'part-prefooter' ); ?>
		</div>
	</div>
</main>

<?php get_footer();
