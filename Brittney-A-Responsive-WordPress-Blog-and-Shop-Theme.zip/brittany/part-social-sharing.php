<div class="entry-item-sharing">
	<?php
		$thumb_id = get_post_thumbnail_id();

		$target = '';
		if ( 1 === (int) get_theme_mod( 'social_target', 1 ) ) {
			$target = 'target="_blank"';
		}

		$facebook = add_query_arg( array(
			'u' => get_permalink(),
		), 'https://www.facebook.com/sharer.php' );

		$twitter = add_query_arg( array(
			'url' => get_permalink(),
		), 'https://twitter.com/share' );

		$pinterest = add_query_arg( array(
			'url'         => get_permalink(),
			'description' => get_the_title(),
			'media'       => wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' ),
		), 'https://pinterest.com/pin/create/bookmarklet/' );
	?>
	<a href="<?php echo esc_url( $facebook ); ?>" <?php echo $target; ?>><i class="fab fa-facebook-f"></i></a>
	<a href="<?php echo esc_url( $twitter ); ?>" <?php echo $target; ?>><i class="fab fa-twitter"></i></a>
	<?php if ( ! empty( $thumb_id ) ) : ?>
		<a href="<?php echo esc_url( $pinterest ); ?>" <?php echo $target; ?>><i class="fab fa-pinterest"></i></a>
	<?php endif; ?>
</div>
