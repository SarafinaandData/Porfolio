	<?php if ( ! is_page_template( 'template-frontpage-fullscreen-slider.php' ) ) : ?>
		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-6">
						<?php dynamic_sidebar( 'footer-1' ); ?>
					</div>

					<div class="col-md-2 col-sm-6">
						<?php dynamic_sidebar( 'footer-2' ); ?>
					</div>
					<div class="col-md-2 col-sm-6">
						<?php dynamic_sidebar( 'footer-3' ); ?>
					</div>

					<div class="col-md-4 col-sm-6">
						<?php dynamic_sidebar( 'footer-4' ); ?>
					</div>
				</div>

				<?php if ( get_theme_mod( 'footer_text', brittany_get_default_footer_text() ) ) : ?>
					<div class="row">
						<div class="col-md-12">
							<p class="footer-credits">
								<?php echo brittany_sanitize_footer_text( get_theme_mod( 'footer_text', brittany_get_default_footer_text() ) ); ?>
							</p>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</footer>
	<?php endif; ?>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
