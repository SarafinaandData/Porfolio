<?php
/*
 * Template Name: Widgetized Homepage with Carousel Slider
 */
?>

<?php get_header(); ?>

<?php if ( get_theme_mod( 'home_slider_show_home', 1 ) ) {
	get_template_part( 'part-slider-carousel' );
} ?>

<main class="main">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section-widgets">
					<?php dynamic_sidebar( 'homepage' ); ?>
				</div>
			</div>
		</div>
	</div>
</main>

<?php get_footer();
