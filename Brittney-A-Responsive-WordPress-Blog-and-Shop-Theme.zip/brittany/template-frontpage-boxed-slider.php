<?php
/*
 * Template Name: Widgetized Homepage with Boxed Slider
 */
?>

<?php get_header(); ?>

<main class="main">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="section-widgets">
					<?php if ( get_theme_mod( 'home_slider_show_home', 1 ) ) : ?>
						<section class="widget">
							<?php get_template_part( 'part-slider' ); ?>
						</section>
					<?php endif; ?>
					<?php dynamic_sidebar( 'homepage' ); ?>
				</div>
			</div>
		</div>
	</div>
</main>

<?php get_footer();
